"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var StakeholderTypeSchema = (function () {
    function StakeholderTypeSchema() {
    }
    Object.defineProperty(StakeholderTypeSchema, "schema", {
        get: function () {
            var key = 'stakeholderTypeId';
            var object = {
                stakeholderTypeId: {
                    type: String,
                    unique: true
                },
                stakeholderTypeCode: {
                    type: String,
                    unique: true,
                    uppercase: true,
                    trim: true
                },
                stakeholderTypeName: {
                    type: String,
                    require: true
                },
                stakeholderTypeDescription: {
                    type: String
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var options = {
                key: key
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return StakeholderTypeSchema;
}());
var schema = mongooseConnection.model("stakeholder_types", StakeholderTypeSchema.schema);
module.exports = schema;
//# sourceMappingURL=StakeholderTypeSchema.js.map