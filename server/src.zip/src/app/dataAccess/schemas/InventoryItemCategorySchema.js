"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var InventoryItemCategorySchema = (function () {
    function InventoryItemCategorySchema() {
    }
    Object.defineProperty(InventoryItemCategorySchema, "schema", {
        get: function () {
            var key = 'inventoryItemCategoryId';
            var object = {
                inventoryItemCategoryId: {
                    type: String,
                    unique: true
                },
                inventoryItemCategoryName: {
                    type: String,
                    require: true,
                },
                inventoryItemCategoryCode: {
                    type: String,
                    unique: true,
                    uppercase: true,
                    trim: true
                },
                inventoryItemCategoryDescription: {
                    type: String
                },
                parent: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'inventory_item_categories',
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var options = {
                'key': key,
                'refs': [
                    {
                        'model': 'inventory_item_categories',
                        'key': {
                            'localField': 'parent',
                            'foreignField': '_id'
                        },
                        'fields': [
                            'inventoryItemCategoryId',
                            'inventoryItemCategoryName'
                        ]
                    }
                ]
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemCategorySchema;
}());
var schema = mongooseConnection.model("inventory_item_categories", InventoryItemCategorySchema.schema);
module.exports = schema;
//# sourceMappingURL=InventoryItemCategorySchema.js.map