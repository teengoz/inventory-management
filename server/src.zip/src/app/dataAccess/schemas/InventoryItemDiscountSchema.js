"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var InventoryItemDiscountSchema = (function () {
    function InventoryItemDiscountSchema() {
    }
    Object.defineProperty(InventoryItemDiscountSchema, "schema", {
        get: function () {
            var object = {
                inventoryItemDiscountId: {
                    type: String,
                    unique: true
                },
                inventoryItem: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'inventory_items'
                },
                inventoryItemDiscountMinQuantity: {
                    type: Number
                },
                inventoryItemDiscountMaxQuantity: {
                    type: Number
                },
                inventoryItemDiscountValue: {
                    type: Number
                },
                inventoryItemDiscountType: {
                    type: Number
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var key = "inventoryItemDiscountId";
            var options = {
                'key': key,
                'refs': [
                    {
                        'model': 'inventory_items',
                        'key': {
                            'localField': 'inventoryItem',
                            'foreignField': '_id'
                        },
                        'fields': [
                            'inventoryItemId',
                            'inventoryItemName'
                        ]
                    }
                ]
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemDiscountSchema;
}());
var schema = mongooseConnection.model("inventory_item_discounts", InventoryItemDiscountSchema.schema);
module.exports = schema;
//# sourceMappingURL=InventoryItemDiscountSchema.js.map