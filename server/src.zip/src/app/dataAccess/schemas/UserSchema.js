"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var UserSchema = (function () {
    function UserSchema() {
    }
    Object.defineProperty(UserSchema, "schema", {
        get: function () {
            var key = "userId";
            var object = {
                username: {
                    type: String,
                    lowercase: true,
                    unique: true,
                    trim: true
                },
                password: {
                    type: String
                },
                hash: {
                    type: String
                },
                salt: {
                    type: String
                },
                jobTitle: {
                    type: String
                },
                fullName: {
                    type: String
                },
                email: {
                    type: String
                },
                phone: {
                    type: String
                },
                address: {
                    type: String
                },
                isActive: {
                    type: String
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var hiddenFields = ['__v', 'createdBy', 'updatedBy'];
            var options = {
                key: key,
                hiddenFields: hiddenFields
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return UserSchema;
}());
var schema = mongooseConnection.model("users", UserSchema.schema);
module.exports = schema;
//# sourceMappingURL=UserSchema.js.map