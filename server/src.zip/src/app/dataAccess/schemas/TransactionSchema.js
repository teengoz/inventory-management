"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var TransactionSchema = (function () {
    function TransactionSchema() {
    }
    Object.defineProperty(TransactionSchema, "schema", {
        get: function () {
            var object = {
                transactionId: {
                    type: String,
                    unique: true
                },
                stakeholder: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'stakeholders'
                },
                transactionType: {
                    type: String,
                    enum: ['1', '2', '3']
                },
                transactionNo: {
                    type: String,
                    unique: true,
                    uppercase: true,
                    trim: true
                },
                transactionDescription: {
                    type: String
                },
                transactionTime: {
                    type: Date,
                    require: true,
                    default: Date.now
                },
                isRecorded: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                }
            };
            var key = 'transactionId';
            var options = {
                'key': key,
                'refs': [
                    {
                        'model': 'stakeholders',
                        'key': {
                            'localField': 'stakeholder',
                            'foreignField': '_id'
                        },
                        'fields': [
                            'stakeholderId',
                            'stakeholderName'
                        ]
                    },
                    {
                        'model': 'transaction_details',
                        'key': {
                            'localField': '_id',
                            'foreignField': 'transaction'
                        },
                        'fields': [
                            'price',
                            'quantity',
                            'stock',
                            'secondStock',
                            'unit',
                            'inventoryItem',
                            'lotNo'
                        ],
                        'as': 'transactionDetailData'
                    }
                ]
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return TransactionSchema;
}());
var schema = mongooseConnection.model("transactions", TransactionSchema.schema);
module.exports = schema;
//# sourceMappingURL=TransactionSchema.js.map