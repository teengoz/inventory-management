"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var StockSchema = (function () {
    function StockSchema() {
    }
    Object.defineProperty(StockSchema, "schema", {
        get: function () {
            var key = "stockId";
            var object = {
                stockId: {
                    type: String,
                    unique: true
                },
                stockName: {
                    type: String
                },
                stockCode: {
                    type: String,
                    unique: true,
                    uppercase: true,
                    trim: true
                },
                stockDescription: {
                    type: String
                },
                stockAddress: {
                    type: String
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var options = {
                key: key
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return StockSchema;
}());
var schema = mongooseConnection.model("Stocks", StockSchema.schema);
module.exports = schema;
//# sourceMappingURL=StockSchema.js.map