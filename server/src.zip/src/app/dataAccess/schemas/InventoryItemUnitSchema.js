"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var InventoryItemUnitSchema = (function () {
    function InventoryItemUnitSchema() {
    }
    Object.defineProperty(InventoryItemUnitSchema, "schema", {
        get: function () {
            var key = "inventoryItemUnitId";
            var transformName = 'inventoryItemUnit';
            var object = {
                inventoryItemUnitId: {
                    type: String,
                    unique: true,
                },
                inventoryItemUnitName: {
                    type: String,
                    require: true,
                    unique: true,
                },
                inventoryItemUnitSymbol: {
                    type: String
                },
                inventoryItemUnitDescription: {
                    type: String
                },
                createBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                }
            };
            var options = {
                key: key
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemUnitSchema;
}());
var schema = mongooseConnection.model("inventory_item_units", InventoryItemUnitSchema.schema);
module.exports = schema;
//# sourceMappingURL=InventoryItemUnitSchema.js.map