"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var StakeholderSchema = (function () {
    function StakeholderSchema() {
    }
    Object.defineProperty(StakeholderSchema, "schema", {
        get: function () {
            var key = 'stakeholderId';
            var object = {
                stakeholderId: {
                    type: String,
                    unique: true
                },
                stakeholderType: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'stakeholder_types',
                    require: true
                },
                stakeholderCode: {
                    type: String,
                    unique: true,
                    require: true
                },
                stakeholderName: {
                    type: String,
                    require: true
                },
                stakeholderDescription: {
                    type: String
                },
                stakeholderAddress: {
                    type: String
                },
                stakeholderGender: {
                    type: String
                },
                stakeholderPhone1: {
                    type: String
                },
                stakeholderPhone2: {
                    type: String
                },
                stakeholderFax: {
                    type: String
                },
                stakeholderEmail: {
                    type: String
                },
                stakeholderTaxcode: {
                    type: String
                },
                stakeholderAccountNumber: {
                    type: String
                },
                stakeholderBank: {
                    type: String
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                },
            };
            var options = {
                'key': key,
                'refs': [
                    {
                        'model': 'stakeholder_types',
                        'key': {
                            'localField': 'stakeholderType',
                            'foreignField': '_id'
                        },
                        'fields': [
                            'stakeholderTypeId',
                            'stakeholderTypeName'
                        ]
                    }
                ]
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            schema.pre('find', function (next) {
                this.populate('stakeholderType', 'stakeholderTypeName');
                next();
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return StakeholderSchema;
}());
var schema = mongooseConnection.model("stakeholders", StakeholderSchema.schema);
module.exports = schema;
//# sourceMappingURL=StakeholderSchema.js.map