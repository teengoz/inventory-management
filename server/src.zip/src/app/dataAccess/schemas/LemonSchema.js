"use strict";
var DataAccess = require("../DataAccess");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var LemonSchema = (function () {
    function LemonSchema() {
    }
    Object.defineProperty(LemonSchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                name: {
                    type: String,
                    required: true
                },
                level: {
                    type: Number,
                    required: true
                },
                color: {
                    type: String,
                    required: true
                },
                source: {
                    type: String,
                    required: false
                }
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return LemonSchema;
}());
var schema = mongooseConnection.model("Lemons", LemonSchema.schema);
module.exports = schema;
//# sourceMappingURL=LemonSchema.js.map