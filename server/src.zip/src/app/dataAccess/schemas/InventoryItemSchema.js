"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var InventoryItemSchema = (function () {
    function InventoryItemSchema() {
    }
    Object.defineProperty(InventoryItemSchema, "schema", {
        get: function () {
            var key = "inventoryItemId";
            var object = {
                inventoryItemId: {
                    type: String,
                    unique: true
                },
                inventoryItemCategory: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'inventory_item_categories'
                },
                inventoryItemName: {
                    type: String,
                    require: function () {
                        return (!!this.inventoryItemName && this.inventoryItemName != '');
                    },
                    trim: true
                },
                inventoryItemCode: {
                    type: String,
                    require: function () {
                        return (!!this.inventoryItemCode && this.inventoryItemCode != '');
                    },
                    unique: true,
                    trim: true
                },
                inventoryItemDescription: {
                    type: String
                },
                inventoryItemMinQuantity: {
                    type: Number
                },
                inventoryItemMaxQuantity: {
                    type: Number
                },
                inventoryItemCostPrice: {
                    type: Number
                },
                inventoryItemBaseUnit: {
                    type: String,
                    require: function () {
                        return (!!this.inventoryItemBaseUnit && this.inventoryItemBaseUnit != '');
                    },
                    trim: true
                },
                inventoryItemConversionUnit: {
                    type: String
                },
                inventoryItemSpecification1: {
                    type: String
                },
                inventoryItemSpecification2: {
                    type: String
                },
                inventoryItemSpecification3: {
                    type: String
                },
                inventoryItemSpecification4: {
                    type: String
                },
                inventoryItemSpecification5: {
                    type: String
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                }
            };
            var options = {
                'key': key,
                'refs': [
                    {
                        'model': 'inventory_item_categories',
                        'key': {
                            'localField': 'inventoryItemCategory',
                            'foreignField': '_id'
                        },
                        'fields': [
                            'inventoryItemCategoryId',
                            'inventoryItemCategoryName'
                        ]
                    }
                ]
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemSchema;
}());
var schema = mongooseConnection.model("inventory_items", InventoryItemSchema.schema);
module.exports = schema;
//# sourceMappingURL=InventoryItemSchema.js.map