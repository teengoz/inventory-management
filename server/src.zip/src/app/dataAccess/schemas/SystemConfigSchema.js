"use strict";
var DataAccess = require("../DataAccess");
var BaseSchema_1 = require("../BaseSchema");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var SystemConfigSchema = (function () {
    function SystemConfigSchema() {
    }
    Object.defineProperty(SystemConfigSchema, "schema", {
        get: function () {
            var key = 'systemConfigId';
            var object = {
                systemConfigId: {
                    type: String,
                    unique: true
                },
                systemConfigName: {
                    type: String,
                    require: true
                },
                systemConfigFieldName: {
                    type: String,
                    unique: true,
                    trim: true
                },
                systemConfigDescription: {
                    type: String
                },
                systemConfigInputType: {
                    type: String,
                    require: true
                },
                systemConfigValue: {
                    type: String
                },
                systemConfigOptionValues: {
                    type: String
                },
                systemConfigControlType: {
                    type: String
                },
                systemConfigLabelWidth: {
                    type: Number
                },
                systemConfigInputWidth: {
                    type: Number
                },
                systemConfigRequired: {
                    type: Boolean
                },
                systemConfigInline: {
                    type: Boolean
                },
                systemConfigOrder: {
                    type: Number
                },
                isActive: {
                    type: Boolean
                },
                createdBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                updatedBy: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'users'
                },
                createdAt: {
                    type: Date,
                    default: Date.now
                },
                updatedAt: {
                    type: Date,
                    default: Date.now
                }
            };
            var options = {
                key: key
            };
            var schema = new BaseSchema_1.BaseSchema(object, options).schema;
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return SystemConfigSchema;
}());
var schema = mongooseConnection.model("system_config", SystemConfigSchema.schema);
module.exports = schema;
//# sourceMappingURL=SystemConfigSchema.js.map