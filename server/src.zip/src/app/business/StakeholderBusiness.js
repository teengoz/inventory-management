"use strict";
var StakeholderRepository = require("../repository/StakeholderRepository");
var StakeholderBusiness = (function () {
    function StakeholderBusiness() {
        this._stakeholderRepository = new StakeholderRepository();
    }
    StakeholderBusiness.prototype.create = function (item, callback) {
        this._stakeholderRepository.create(item, callback);
    };
    StakeholderBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._stakeholderRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else if (res)
                _this._stakeholderRepository.update(res._id, item, callback);
        });
    };
    StakeholderBusiness.prototype.delete = function (_id, callback) {
        this._stakeholderRepository.delete(_id, callback);
    };
    StakeholderBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._stakeholderRepository.retrieve(callback, _options);
    };
    StakeholderBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._stakeholderRepository.find(callback, _options);
    };
    StakeholderBusiness.prototype.search = function (_keyword, callback) {
        if (!!_keyword) {
            var _options = {};
            _options['cond'] = {};
            _options['cond']['filter'] = {
                $or: [
                    { 'stakeholderCode': new RegExp(_keyword, 'i') },
                    { 'stakeholderName': new RegExp(_keyword, 'i') }
                ]
            };
            _options['cond']['type'] = 'search';
            this._stakeholderRepository.find(callback, _options);
        }
        else {
            this._stakeholderRepository.retrieve(callback, {});
        }
    };
    StakeholderBusiness.prototype.findById = function (_id, callback) {
        this._stakeholderRepository.findById(_id, callback);
    };
    StakeholderBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._stakeholderRepository.meta(callback, _options);
    };
    return StakeholderBusiness;
}());
Object.seal(StakeholderBusiness);
module.exports = StakeholderBusiness;
//# sourceMappingURL=StakeholderBusiness.js.map