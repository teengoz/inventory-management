"use strict";
var InventoryItemDiscountRepository = require("../repository/InventoryItemDiscountRepository");
var InventoryItemBusiness = (function () {
    function InventoryItemBusiness() {
        this._inventoryItemDiscountRepository = new InventoryItemDiscountRepository();
    }
    InventoryItemBusiness.prototype.create = function (item, callback) {
        this._inventoryItemDiscountRepository.create(item, callback);
    };
    InventoryItemBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._inventoryItemDiscountRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._inventoryItemDiscountRepository.update(res._id, item, callback);
        });
    };
    InventoryItemBusiness.prototype.delete = function (_id, callback) {
        this._inventoryItemDiscountRepository.delete(_id, callback);
    };
    InventoryItemBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._inventoryItemDiscountRepository.retrieve(callback, _options);
    };
    InventoryItemBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._inventoryItemDiscountRepository.find(callback, _options);
    };
    InventoryItemBusiness.prototype.findById = function (_id, callback) {
        this._inventoryItemDiscountRepository.findById(_id, callback);
    };
    InventoryItemBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._inventoryItemDiscountRepository.meta(callback, _options);
    };
    return InventoryItemBusiness;
}());
Object.seal(InventoryItemBusiness);
module.exports = InventoryItemBusiness;
//# sourceMappingURL=InventoryItemDiscountBusiness.js.map