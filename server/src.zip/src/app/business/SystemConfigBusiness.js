"use strict";
var SystemConfigRepository = require("../repository/SystemConfigRepository");
var SystemConfigBusiness = (function () {
    function SystemConfigBusiness() {
        this._systemconfigRepository = new SystemConfigRepository();
    }
    SystemConfigBusiness.prototype.create = function (item, callback) {
        this._systemconfigRepository.create(item, callback);
    };
    SystemConfigBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._systemconfigRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._systemconfigRepository.update(res._id, item, callback);
        });
    };
    SystemConfigBusiness.prototype.retrieveConfigList = function (fieldNames, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = { "systemConfigFieldName": { $in: fieldNames } };
        _options['cond']['type'] = '$in';
        _options['cond']['sort'] = { "systemConfigOrder": 1 };
        this._systemconfigRepository.find(callback, _options);
    };
    SystemConfigBusiness.prototype.findByFieldName = function (fieldName, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = { 'systemConfigFieldName': fieldName };
        this._systemconfigRepository.find(function (error, result) {
            console.log('resultresultresultresultresult');
            console.log(_options);
            console.log(result);
            callback(error, result[0]);
        }, _options);
    };
    return SystemConfigBusiness;
}());
Object.seal(SystemConfigBusiness);
module.exports = SystemConfigBusiness;
//# sourceMappingURL=SystemConfigBusiness.js.map