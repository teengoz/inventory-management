"use strict";
var StakeholderTypeRepository = require("../repository/StakeholderTypeRepository");
var StakeholderTypeBusiness = (function () {
    function StakeholderTypeBusiness() {
        this._stakeholderTypeRepository = new StakeholderTypeRepository();
    }
    StakeholderTypeBusiness.prototype.create = function (item, callback) {
        this._stakeholderTypeRepository.create(item, callback);
    };
    StakeholderTypeBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._stakeholderTypeRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else if (res)
                _this._stakeholderTypeRepository.update(res._id, item, callback);
        });
    };
    StakeholderTypeBusiness.prototype.delete = function (_id, callback) {
        this._stakeholderTypeRepository.delete(_id, callback);
    };
    StakeholderTypeBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._stakeholderTypeRepository.retrieve(callback, _options);
    };
    StakeholderTypeBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._stakeholderTypeRepository.find(callback, _options);
    };
    StakeholderTypeBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._stakeholderTypeRepository.meta(callback, _options);
    };
    StakeholderTypeBusiness.prototype.findById = function (_id, callback) {
        this._stakeholderTypeRepository.findById(_id, callback);
    };
    return StakeholderTypeBusiness;
}());
Object.seal(StakeholderTypeBusiness);
module.exports = StakeholderTypeBusiness;
//# sourceMappingURL=StakeholderTypeBusiness.js.map