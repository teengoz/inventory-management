"use strict";
var TransactionDetailRepository = require("../repository/TransactionDetailRepository");
var mongoose = require("mongoose");
var TransactionDetailBusiness = (function () {
    function TransactionDetailBusiness() {
        this._transactionDetailRepository = new TransactionDetailRepository();
    }
    TransactionDetailBusiness.prototype.create = function (req, callback) {
        var body = req.body;
        var item;
        // if (!item['inventoryItemName'] || !item['inventoryItemCostPrice'] || !item['inventoryItemBaseUnit']) {
        //     callback('error', null);
        //     return;
        // }
        //
        // let userId = req['payload']['_id'];
        // item['createdBy'] = userId;
        //
        // let inventoryItemCategoryId = body['basic']['inventoryItemCategory.inventoryItemCategoryId'];
        // item['inventoryItemCategory'] = inventoryItemCategoryId;
        //
        // let inventoryItemConversionUnit = body['unitConversion'];
        // item['inventoryItemConversionUnit'] = JSON.stringify(inventoryItemConversionUnit);
        //
        // let specification = body['specification'];
        // for (let i = 0; i < 5; i++) {
        //     let spec = specification[i];
        //     if (spec) {
        //         item['inventoryItemSpecification' + (i + 1)] = spec;
        //     }
        // }
        //
        // if (!body['inventoryItemCode']) {
        //     let newId = new Date().getTime().toString();
        //     item['inventoryItemCode'] = newId;
        // }
        this._transactionDetailRepository.create(item, callback);
    };
    TransactionDetailBusiness.prototype.insert = function (detail, callback) {
        this._transactionDetailRepository.create(detail, callback);
    };
    TransactionDetailBusiness.prototype.validDetail = function (object) {
        return false;
    };
    TransactionDetailBusiness.prototype.update = function (_id, item, callback) {
        this._transactionDetailRepository.update(_id, item, callback);
    };
    ;
    TransactionDetailBusiness.prototype.updateItem = function (req, callback) {
        var _this = this;
        var _id = req.params._id;
        this._transactionDetailRepository.findById(_id, function (error, result) {
            if (error)
                callback(error, result);
            else {
                var body = req.body;
                var currentItem = result;
                var item = body['basic'];
                if (!item['inventoryItemCode']) {
                    delete item['inventoryItemCode'];
                }
                item['inventoryItemCode'] = currentItem['inventoryItemCode'];
                if (!item['inventoryItemName'] || !item['inventoryItemCostPrice'] || !item['inventoryItemBaseUnit']) {
                    callback('error', null);
                    return;
                }
                var userId = req['payload']['_id'];
                item['createdBy'] = userId;
                var inventoryItemCategoryId = body['basic']['inventoryItemCategory.inventoryItemCategoryId'];
                item['inventoryItemCategory'] = inventoryItemCategoryId;
                delete item['inventoryItemCategory.inventoryItemCategoryId'];
                var inventoryItemConversionUnit = body['unitConversion'];
                item['inventoryItemConversionUnit'] = JSON.stringify(inventoryItemConversionUnit);
                var specification = body['specification'];
                for (var i = 0; i < 5; i++) {
                    var spec = specification[i];
                    if (spec) {
                        item['inventoryItemSpecification' + (i + 1)] = spec;
                    }
                    else {
                        item['inventoryItemSpecification' + (i + 1)] = null;
                    }
                }
                _this._transactionDetailRepository.update(currentItem._id, item, callback);
            }
        });
    };
    TransactionDetailBusiness.prototype.delete = function (_id, callback) {
        this._transactionDetailRepository.delete(_id, callback);
    };
    TransactionDetailBusiness.prototype.deteleByTransactionId = function (_transactionId, callback) {
        this._transactionDetailRepository.removeByTransactionId(_transactionId, callback);
    };
    TransactionDetailBusiness.prototype.deleteUnupdatedTransactionDetail = function (transactionId, updatedTransactionDetailIds, callback) {
        this._transactionDetailRepository.removeUnupdatedTransactionDetail(transactionId, updatedTransactionDetailIds, callback);
    };
    TransactionDetailBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._transactionDetailRepository.retrieve(callback, _options);
    };
    TransactionDetailBusiness.prototype.findByTransactionId = function (_transactionId, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = { 'transaction._id': new mongoose.Types.ObjectId(_transactionId) };
        _options['cond']['type'] = '=';
        this._transactionDetailRepository.find(callback, _options);
    };
    TransactionDetailBusiness.prototype.findByInventoryItemId = function (_inventoryItemId, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = {
            $and: [
                { 'inventoryItem.inventoryItemId': _inventoryItemId },
                { "transaction.isRecorded": true }
            ]
        };
        _options['cond']['type'] = '=';
        _options['fields'] = [
            'transactionType', 'realQuantity'
        ];
        this._transactionDetailRepository.find(callback, _options);
    };
    TransactionDetailBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._transactionDetailRepository.find(callback, _options);
    };
    TransactionDetailBusiness.prototype.findById = function (_id, callback) {
        this._transactionDetailRepository.findById(_id, callback);
    };
    TransactionDetailBusiness.prototype.findCode = function (_code, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = { 'inventoryItemCode': _code };
        _options['cond']['type'] = '=';
        this._transactionDetailRepository.find(callback, _options);
    };
    TransactionDetailBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._transactionDetailRepository.meta(callback, _options);
    };
    return TransactionDetailBusiness;
}());
Object.seal(TransactionDetailBusiness);
module.exports = TransactionDetailBusiness;
//# sourceMappingURL=TransactionDetailBusiness.js.map