"use strict";
var LemonRepository = require("./../repository/LemonRepository");
var LemonBusiness = (function () {
    function LemonBusiness() {
        this._lemonRepository = new LemonRepository();
    }
    LemonBusiness.prototype.create = function (item, callback) {
        this._lemonRepository.create(item, callback);
    };
    LemonBusiness.prototype.retrieve = function (callback) {
        this._lemonRepository.retrieve(callback);
    };
    LemonBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._lemonRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._lemonRepository.update(res._id, item, callback);
        });
    };
    LemonBusiness.prototype.delete = function (_id, callback) {
        this._lemonRepository.delete(_id, callback);
    };
    LemonBusiness.prototype.findById = function (_id, callback) {
        this._lemonRepository.findById(_id, callback);
    };
    return LemonBusiness;
}());
Object.seal(LemonBusiness);
module.exports = LemonBusiness;
//# sourceMappingURL=LemonBusiness.js.map