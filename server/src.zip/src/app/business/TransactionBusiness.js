"use strict";
var TransactionRepository = require("../repository/TransactionRepository");
var InventoryItemBusiness = require("../business/InventoryItemBusiness");
var StockBusiness = require("../business/StockBusiness");
var TransactionDetailBusiness = require("../business/TransactionDetailBusiness");
var TRANSFER_TRANSACTION = 3;
var INWARD_TRANSACTION = 1;
var OUTWARD_TRANSACTION = 2;
var TRANSACTION_TYPE;
(function (TRANSACTION_TYPE) {
    TRANSACTION_TYPE[TRANSACTION_TYPE["TRANSFER_TRANSACTION"] = 0] = "TRANSFER_TRANSACTION";
    TRANSACTION_TYPE[TRANSACTION_TYPE["INWARD_TRANSACTION"] = 1] = "INWARD_TRANSACTION";
    TRANSACTION_TYPE[TRANSACTION_TYPE["OUTWARD_TRANSACTION"] = 2] = "OUTWARD_TRANSACTION";
})(TRANSACTION_TYPE || (TRANSACTION_TYPE = {}));
var TransactionBusiness = (function () {
    function TransactionBusiness() {
        this._transactionRepository = new TransactionRepository();
        this._transactionDetailRepository = new TransactionDetailBusiness();
    }
    TransactionBusiness.prototype.create = function (req, callback) {
        var _this = this;
        // Basic data
        var body = req.body;
        var basic = req.body['basic'];
        // Detail data
        var plainDetailData = req.body['detail'];
        var item = {};
        var transactionDetails;
        // User Id for createdBy
        var userId = req['payload']['_id'];
        item['createdBy'] = userId;
        // Generate auto id
        var newId = new Date().getTime().toString();
        // Assign basic data
        this._transactionType = item['transactionType'] = basic['transactionType'];
        item['transactionNo'] = newId;
        item['transactionDescription'] = basic['description'];
        var time = (+basic['time'] == 0) ? new Date() : new Date(+basic['time'] * 1000);
        item['transactionTime'] = time;
        item['isRecorded'] = basic['isRecorded'] || false;
        if (basic['transactionType'] != TRANSFER_TRANSACTION) {
            item['stakeholder'] = basic['stakeholder'];
        }
        // Initialize detail rows
        var detailRows = [];
        //Valid plain data
        this.validDetailData(this, plainDetailData, detailRows, this.validDetailData, function () {
            console.log('Error validDetailData');
            console.log('error');
        }, function (validData) {
            // console.log('BASIC');
            // console.log(item);
            // console.log('insertTransaction');
            // console.log(data);
            _this.insertTransaction(item, validData, callback);
        });
        //callback('error', null);
        //this._transactionRepository.create(item, callback);
    };
    TransactionBusiness.prototype.insertTransaction = function (item, data, callback) {
        var _this = this;
        this._transactionRepository.create(item, function (error, result) {
            var createdBy = result['createdBy'];
            var transactionId = result['transactionId'];
            var transactionType = result['transactionType'];
            // Values in exist in all of item in transactionDetailData
            var commonData = {
                createdBy: createdBy, transactionId: transactionId, transactionType: transactionType
            };
            _this.insertTransactionDetail(commonData, data, callback);
        });
    };
    /**
     * commonData = Values in exist in all of item in transactionDetailData
     * data = Array of transactionDetail
     */
    TransactionBusiness.prototype.insertTransactionDetail = function (commonData, data, callback) {
        var transactionDetailBusiness = new TransactionDetailBusiness();
        var base = this;
        if (data.length > 0) {
            var _detail = data.pop();
            _detail['createdBy'] = commonData['user'];
            _detail['transaction'] = commonData['transactionId'];
            _detail['transactionType'] = commonData['transactionType'];
            transactionDetailBusiness.insert(_detail, function (error, result) {
                base.insertTransactionDetail(commonData, data, callback);
            });
        }
        else {
            callback(null, 'DONE');
        }
    };
    TransactionBusiness.prototype.updateByRequestData = function (req, callback) {
        var _this = this;
        // Basic data
        var body = req.body;
        var basic = req.body['basic'];
        var _id = req.params._id;
        // Detail data
        var plainDetailData = req.body['detail'];
        var item = {};
        var transactionDetails;
        // Transaction Id
        item['transactionId'] = _id;
        // User Id for updatedBy
        var userId = req['payload']['_id'];
        item['updatedBy'] = userId;
        this._transactionType = basic['transactionType'];
        item['transactionDescription'] = basic['description'];
        var time = (+basic['time'] == 0) ? new Date().getTime() : +basic['time'];
        item['transactionTime'] = new Date(time * 1000);
        item['isRecorded'] = basic['isRecorded'] || false;
        if (basic['transactionType'] != TRANSFER_TRANSACTION) {
            item['stakeholder'] = basic['stakeholder'];
        }
        // Initialize detail rows
        var detailRows = [];
        //Valid plain data
        this.validDetailData(this, plainDetailData, detailRows, this.validDetailData, function () {
            console.log('Error validDetailData');
            console.log('error');
        }, function (validData) {
            // Use method for save detail data
            _this.updateTransaction(item, validData, callback);
        });
    };
    TransactionBusiness.prototype.updateTransaction = function (item, validData, callback) {
        var _this = this;
        console.log('--------------updateTransaction--------------');
        this._transactionRepository.update(item['transactionId'], item, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            var user = item['updatedBy'];
            var transactionId = item['transactionId'];
            var transactionType = result['transactionType'];
            var updateTransactionDetailIds = [];
            // Values in exist in all of items in transactionDetailData
            var commonData = {
                user: user, transactionId: transactionId, transactionType: transactionType, updateTransactionDetailIds: updateTransactionDetailIds
            };
            _this.saveTransactionDetail(commonData, validData, callback);
        });
    };
    TransactionBusiness.prototype.saveTransactionDetail = function (commonData, data, callback) {
        var transactionDetailBusiness = new TransactionDetailBusiness();
        var base = this;
        if (data.length > 0) {
            var _detail_1 = data.pop();
            if (_detail_1['transactionDetailId']) {
                _detail_1['updatedBy'] = commonData['user'];
                _detail_1['transaction'] = commonData['transactionId'];
                _detail_1['transactionType'] = commonData['transactionType'];
                transactionDetailBusiness.update(_detail_1['transactionDetailId'], _detail_1, function (error, result) {
                    commonData['updateTransactionDetailIds'].push(_detail_1['transactionDetailId']);
                    base.saveTransactionDetail(commonData, data, callback);
                });
            }
            else {
                _detail_1['createdBy'] = commonData['user'];
                _detail_1['transaction'] = commonData['transactionId'];
                transactionDetailBusiness.insert(_detail_1, function (error, result) {
                    base.saveTransactionDetail(commonData, data, callback);
                });
            }
        }
        else {
            if (commonData['updateTransactionDetailIds']) {
                console.log('--------------deleteUnupdatedTransactionDetail--------------');
                console.log(commonData['updateTransactionDetailIds']);
                transactionDetailBusiness.deleteUnupdatedTransactionDetail(commonData['transactionId'], commonData['updateTransactionDetailIds'], function (error) {
                    callback(error, 'DONE');
                });
            }
            else {
                callback(null, 'DONE');
            }
        }
    };
    TransactionBusiness.prototype.record = function (_id, _record, callback) {
        var _this = this;
        this._transactionRepository.findById(_id, function (err, res) {
            if (err) {
                callback(err, res);
            }
            else {
                var placeholderTransaction = {};
                placeholderTransaction.isRecorded = _record;
                //console.log(res);
                _this._transactionRepository.update(res._id, placeholderTransaction, callback);
                //callback(null, "DONE");
            }
        });
    };
    TransactionBusiness.prototype.update = function (_id, item, callback) {
    };
    ;
    TransactionBusiness.prototype.delete = function (_id, callback) {
        this._transactionRepository.delete(_id, function (error, result) {
            var transactionDetailBusiness = new TransactionDetailBusiness();
            transactionDetailBusiness.deteleByTransactionId(_id, callback);
        });
    };
    TransactionBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        _options['cond'] = {};
        _options['cond']['sort'] = {
            'transactionTime': -1
        };
        console.log('RETRIVE--------');
        console.log(_options);
        this._transactionRepository.retrieve(callback, _options);
    };
    TransactionBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._transactionRepository.find(callback, _options);
    };
    TransactionBusiness.prototype.findById = function (_id, callback) {
        this._transactionRepository.findById(_id, function (error, result) {
            var transaction = result;
            var transactionId = result.transactionId;
            var transactionDetailBusiness = new TransactionDetailBusiness();
            transactionDetailBusiness.findByTransactionId(transactionId, function (error, result) {
                transaction['transactionDetailData'] = result;
                callback(null, transaction);
            });
        });
    };
    TransactionBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._transactionRepository.meta(callback, _options);
    };
    /**
     * base = this
     * data = plain data
     * validData = the data is valid
     * loopCallback = execute validation the next position in plainDetailData
     * failCallback = execute when there is a item which is invalid
     * nextCallback = execute when all of item in plainData are valid
     */
    TransactionBusiness.prototype.validDetailData = function (base, data, validData, loopCallback, failCallback, nextCallback) {
        if (data.length > 0) {
            var currentDetail_1 = data.pop();
            if (!base.isValidStock(currentDetail_1)) {
                failCallback();
                return;
            }
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.findById(currentDetail_1['item'], function (error, result) {
                if (error) {
                    failCallback();
                }
                else {
                    var currentInventoryItem_1 = result;
                    // Check stock data for valid information
                    var stockBusiness = new StockBusiness();
                    var stocks = [];
                    if (currentDetail_1['stock']) {
                        stocks.push(currentDetail_1['stock']);
                    }
                    if (currentDetail_1['secondStock']) {
                        stocks.push(currentDetail_1['secondStock']);
                    }
                    /**
                     * check existence of stocks
                     * assign value for transactionDetail
                     * add transactionDetail to validData
                     * execute loopCallback
                     */
                    stockBusiness.getByIds(stocks, function (error, result) {
                        if (error || result.length < 0) {
                            failCallback();
                        }
                        else {
                            var inventoryItemId = currentInventoryItem_1.inventoryItemId;
                            var inventoryItemBaseUnit = currentInventoryItem_1.inventoryItemBaseUnit;
                            var inventoryItemConversionUnit = JSON.parse(currentInventoryItem_1.inventoryItemConversionUnit);
                            var _detail = {};
                            if (currentDetail_1['id']) {
                                _detail['transactionDetailId'] = currentDetail_1['id'];
                            }
                            _detail['inventoryItem'] = inventoryItemId;
                            _detail['stock'] = currentDetail_1['stock'];
                            if (currentDetail_1['secondStock']) {
                                _detail['secondStock'] = currentDetail_1['secondStock'];
                            }
                            var indexOfUnit = base.isValidUnit(currentDetail_1['unit'], inventoryItemConversionUnit);
                            var rate = 1;
                            if (currentDetail_1['unit'].toLowerCase() != inventoryItemBaseUnit.toLowerCase()) {
                                if (indexOfUnit == -1) {
                                    failCallback();
                                }
                                else {
                                    rate = inventoryItemConversionUnit[indexOfUnit]['inventoryItemUnitConversionRate'];
                                }
                            }
                            _detail['unit'] = currentDetail_1['unit'];
                            _detail['quantity'] = +currentDetail_1['quantity'] || 0;
                            _detail['price'] = +currentDetail_1['price'] || 0;
                            _detail['baseUnit'] = inventoryItemBaseUnit;
                            _detail['conversionRate'] = rate;
                            _detail['realQuantity'] = rate * _detail['quantity'];
                            _detail['lotNo'] = currentDetail_1['lotNo'];
                            validData.push(_detail);
                            loopCallback(base, data, validData, loopCallback, failCallback, nextCallback);
                        }
                    });
                }
            });
        }
        else {
            if (nextCallback)
                nextCallback(validData);
        }
    };
    TransactionBusiness.prototype.isValidStock = function (detail) {
        if (!detail['stock']) {
            return false;
        }
        else if (this._transactionType == TRANSFER_TRANSACTION && !detail['secondStock']) {
            return false;
        }
        else if (detail['secondStock'] && detail['secondStock'] == detail['stock']) {
            return false;
        }
        return true;
    };
    TransactionBusiness.prototype.isValidUnit = function (unit, unitList) {
        if (unitList && unitList.length > 0) {
            for (var i = 0; i < unitList.length; i++) {
                if (unit.toLowerCase() == unitList[i]['inventoryItemUnitConversionName'].toLowerCase()) {
                    return i;
                }
            }
        }
        return -1;
    };
    return TransactionBusiness;
}());
Object.seal(TransactionBusiness);
module.exports = TransactionBusiness;
//# sourceMappingURL=TransactionBusiness.js.map