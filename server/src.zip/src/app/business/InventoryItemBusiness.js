"use strict";
var InventoryItemRepository = require("../repository/InventoryItemRepository");
var TransactionDetailRepository = require("../repository/TransactionDetailRepository");
var TransactionDetailBusiness = require("./TransactionDetailBusiness");
var InventoryItemBusiness = (function () {
    function InventoryItemBusiness() {
        this._inventoryitemRepository = new InventoryItemRepository();
        this._transactionDetailRepository = new TransactionDetailRepository();
    }
    InventoryItemBusiness.prototype.create = function (req, callback) {
        var body = req.body;
        var item = req.body['basic'];
        if (!item['inventoryItemName'] || !item['inventoryItemCostPrice'] || !item['inventoryItemBaseUnit']) {
            callback('error', null);
            return;
        }
        var userId = req['payload']['_id'];
        item['createdBy'] = userId;
        var inventoryItemCategoryId = body['basic']['inventoryItemCategory.inventoryItemCategoryId'];
        item['inventoryItemCategory'] = inventoryItemCategoryId;
        var inventoryItemConversionUnit = body['unitConversion'];
        item['inventoryItemConversionUnit'] = JSON.stringify(inventoryItemConversionUnit);
        var specification = body['specification'];
        for (var i = 0; i < 5; i++) {
            var spec = specification[i];
            if (spec) {
                item['inventoryItemSpecification' + (i + 1)] = spec;
            }
        }
        if (!body['inventoryItemCode']) {
            var newId = new Date().getTime().toString();
            item['inventoryItemCode'] = newId;
        }
        this._inventoryitemRepository.create(item, callback);
    };
    InventoryItemBusiness.prototype.update = function (_id, item, callback) {
    };
    ;
    InventoryItemBusiness.prototype.updateItem = function (req, callback) {
        var _this = this;
        var _id = req.params._id;
        this._inventoryitemRepository.findById(_id, function (error, result) {
            if (error)
                callback(error, result);
            else {
                var body = req.body;
                var currentItem = result;
                var item = body['basic'];
                if (!item['inventoryItemCode']) {
                    delete item['inventoryItemCode'];
                }
                item['inventoryItemCode'] = currentItem['inventoryItemCode'];
                if (!item['inventoryItemName'] || !item['inventoryItemCostPrice'] || !item['inventoryItemBaseUnit']) {
                    callback('error', null);
                    return;
                }
                var userId = req['payload']['_id'];
                item['createdBy'] = userId;
                var inventoryItemCategoryId = body['basic']['inventoryItemCategory.inventoryItemCategoryId'];
                item['inventoryItemCategory'] = inventoryItemCategoryId;
                delete item['inventoryItemCategory.inventoryItemCategoryId'];
                var inventoryItemConversionUnit = body['unitConversion'];
                item['inventoryItemConversionUnit'] = JSON.stringify(inventoryItemConversionUnit);
                var specification = body['specification'];
                for (var i = 0; i < 5; i++) {
                    var spec = specification[i];
                    if (spec) {
                        item['inventoryItemSpecification' + (i + 1)] = spec;
                    }
                    else {
                        item['inventoryItemSpecification' + (i + 1)] = null;
                    }
                }
                _this._inventoryitemRepository.update(currentItem._id, item, callback);
            }
        });
    };
    InventoryItemBusiness.prototype.delete = function (_id, callback) {
        this._inventoryitemRepository.delete(_id, callback);
    };
    InventoryItemBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._inventoryitemRepository.retrieve(callback, _options);
    };
    InventoryItemBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._inventoryitemRepository.find(callback, _options);
    };
    InventoryItemBusiness.prototype.findById = function (_id, callback) {
        this._inventoryitemRepository.findById(_id, callback);
    };
    InventoryItemBusiness.prototype.getQuantity = function (_id, callback) {
        this._transactionDetailRepository.getQuantity(_id, function (error, result) {
            callback(null, result);
        });
    };
    /**
     * Search inventoryItems by itemCode or itemName
     */
    InventoryItemBusiness.prototype.search = function (_keyword, callback) {
        var _this = this;
        console.log('SEARCH--------');
        if (!!_keyword) {
            var _options = {};
            _options['cond'] = {};
            _options['cond']['filter'] = {
                $or: [
                    { 'inventoryItemCode': new RegExp(_keyword, 'i') },
                    { 'inventoryItemName': new RegExp(_keyword, 'i') }
                ]
            };
            _options['cond']['type'] = 'search';
            _options['fields'] = [
                '_id',
                'inventoryItemId',
                'inventoryItemCode',
                'inventoryItemName',
                'inventoryItemConversionUnit',
                'inventoryItemBaseUnit'
            ];
            this._inventoryitemRepository.find(function (error, result) {
                var inventoryItems = result;
                var inventoryItemId = inventoryItems[0]['inventoryItemId'];
                var transactionDetailBusiness = new TransactionDetailBusiness();
                var computedInventoryItems = [];
                _this.computeQuantity(_this, inventoryItems, computedInventoryItems, function (result) {
                    callback(null, result);
                });
            }, _options);
        }
        else {
            this._inventoryitemRepository.retrieve(callback, {});
        }
    };
    InventoryItemBusiness.prototype.computeQuantity = function (base, orginalInventoryItems, computedInventoryItems, nextCallback) {
        if (orginalInventoryItems.length > 0) {
            var currentInventoryItem_1 = orginalInventoryItems.pop();
            var inventoryItemId = currentInventoryItem_1['inventoryItemId'];
            var transactionDetailBusiness = new TransactionDetailBusiness();
            transactionDetailBusiness.findByInventoryItemId(inventoryItemId, function (error, result) {
                var instock = 0;
                for (var i = 0; i < result.length; i++) {
                    var realQuantity = +result[i]['realQuantity'];
                    switch (+result[i]['transactionType']) {
                        case 1:
                            realQuantity *= 1;
                            break;
                        case 2:
                            realQuantity *= -1;
                            break;
                        case 3:
                            realQuantity *= 0;
                            break;
                        default:
                            realQuantity *= 0;
                    }
                    instock += realQuantity;
                }
                currentInventoryItem_1['instock'] = instock;
                computedInventoryItems.push(currentInventoryItem_1);
                base.computeQuantity(base, orginalInventoryItems, computedInventoryItems, nextCallback);
            });
        }
        else {
            console.log(computedInventoryItems);
            nextCallback(computedInventoryItems);
        }
    };
    InventoryItemBusiness.prototype.findCode = function (_code, callback) {
        var _options = {};
        _options['cond'] = {};
        _options['cond']['filter'] = { 'inventoryItemCode': _code };
        _options['cond']['type'] = '=';
        this._inventoryitemRepository.find(callback, _options);
    };
    InventoryItemBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._inventoryitemRepository.meta(callback, _options);
    };
    return InventoryItemBusiness;
}());
Object.seal(InventoryItemBusiness);
module.exports = InventoryItemBusiness;
//# sourceMappingURL=InventoryItemBusiness.js.map