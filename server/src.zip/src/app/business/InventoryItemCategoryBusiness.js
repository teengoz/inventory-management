"use strict";
var InventoryItemCategoryRepository = require("../repository/InventoryItemCategoryRepository");
var InventoryItemCategoryBusiness = (function () {
    function InventoryItemCategoryBusiness() {
        this._inventoryItemCategoryRepository = new InventoryItemCategoryRepository();
    }
    InventoryItemCategoryBusiness.prototype.create = function (item, callback) {
        this._inventoryItemCategoryRepository.create(item, callback);
    };
    InventoryItemCategoryBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._inventoryItemCategoryRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else if (res)
                _this._inventoryItemCategoryRepository.update(res._id, item, callback);
        });
    };
    InventoryItemCategoryBusiness.prototype.delete = function (_id, callback) {
        this._inventoryItemCategoryRepository.delete(_id, callback);
    };
    InventoryItemCategoryBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._inventoryItemCategoryRepository.retrieve(callback, _options);
    };
    InventoryItemCategoryBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._inventoryItemCategoryRepository.find(callback, _options);
    };
    InventoryItemCategoryBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._inventoryItemCategoryRepository.meta(callback, _options);
    };
    InventoryItemCategoryBusiness.prototype.findById = function (_id, callback) {
        this._inventoryItemCategoryRepository.findById(_id, callback);
    };
    return InventoryItemCategoryBusiness;
}());
Object.seal(InventoryItemCategoryBusiness);
module.exports = InventoryItemCategoryBusiness;
//# sourceMappingURL=InventoryItemCategoryBusiness.js.map