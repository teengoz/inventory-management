"use strict";
var InventoryItemUnitRepository = require("../repository/InventoryItemUnitRepository");
var InventoryItemUnitBusiness = (function () {
    function InventoryItemUnitBusiness() {
        this._inventoryitemunitRepository = new InventoryItemUnitRepository();
    }
    InventoryItemUnitBusiness.prototype.create = function (item, callback) {
        this._inventoryitemunitRepository.create(item, callback);
    };
    InventoryItemUnitBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._inventoryitemunitRepository.retrieve(callback, _options);
    };
    InventoryItemUnitBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._inventoryitemunitRepository.find(callback, _options);
    };
    InventoryItemUnitBusiness.prototype.findById = function (_id, callback) {
        this._inventoryitemunitRepository.findById(_id, callback);
    };
    InventoryItemUnitBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._inventoryitemunitRepository.meta(callback, _options);
    };
    InventoryItemUnitBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._inventoryitemunitRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else if (res)
                _this._inventoryitemunitRepository.update(res._id, item, callback);
        });
    };
    InventoryItemUnitBusiness.prototype.delete = function (_id, callback) {
        this._inventoryitemunitRepository.delete(_id, callback);
    };
    return InventoryItemUnitBusiness;
}());
Object.seal(InventoryItemUnitBusiness);
module.exports = InventoryItemUnitBusiness;
//# sourceMappingURL=InventoryItemUnitBusiness.js.map