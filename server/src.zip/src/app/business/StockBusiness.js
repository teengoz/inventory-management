"use strict";
var StockRepository = require("../repository/StockRepository");
var StockBusiness = (function () {
    function StockBusiness() {
        this._stockRepository = new StockRepository();
    }
    StockBusiness.prototype.create = function (item, callback) {
        this._stockRepository.create(item, callback);
    };
    StockBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._stockRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._stockRepository.update(res._id, item, callback);
        });
    };
    StockBusiness.prototype.delete = function (_id, callback) {
        this._stockRepository.delete(_id, callback);
    };
    StockBusiness.prototype.retrieve = function (callback, options) {
        var _options = options || {};
        this._stockRepository.retrieve(callback, _options);
    };
    StockBusiness.prototype.query = function (callback, options) {
        var _options = options || {};
        this._stockRepository.find(callback, _options);
    };
    StockBusiness.prototype.meta = function (callback, options) {
        var _options = options || {};
        this._stockRepository.meta(callback, _options);
    };
    StockBusiness.prototype.findById = function (_id, callback) {
        this._stockRepository.findById(_id, callback);
    };
    StockBusiness.prototype.getByIds = function (_ids, callback) {
        this._stockRepository.getByIds(_ids, callback);
    };
    StockBusiness.prototype.search = function (_keyword, callback) {
        if (!!_keyword) {
            var _options = {};
            _options['cond'] = {};
            _options['cond']['filter'] = {
                $or: [
                    { 'stockCode': new RegExp(_keyword, 'i') },
                    { 'stockName': new RegExp(_keyword, 'i') }
                ]
            };
            _options['cond']['type'] = 'search';
            this._stockRepository.find(callback, _options);
        }
        else {
            this._stockRepository.retrieve(callback, {});
        }
    };
    return StockBusiness;
}());
Object.seal(StockBusiness);
module.exports = StockBusiness;
//# sourceMappingURL=StockBusiness.js.map