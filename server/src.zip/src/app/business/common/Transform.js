"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var transform_fields_1 = require("../../../config/constants/transform-fields");
var TransformFields = (function () {
    function TransformFields(name) {
        if (name === void 0) { name = null; }
        if (name) {
            this.transformFields = transform_fields_1.transformFields[name];
        }
    }
    // transform(object: T): T {
    //     console.log(object);
    //     if (object) {
    //         this.transformFields.forEach(function(elm, idx) {
    //             let transformName = Object.keys(elm)[0];
    //             let originalName = elm[transformName];
    //             console.log(originalName);
    //             console.log(transformName);
    //             if (object.hasOwnProperty(originalName)) {
    //                 object[transformName] = object[originalName];
    //                 delete object[originalName];
    //             }
    //         });
    //     }
    //     return object;
    // }
    //To Camel Case
    TransformFields.prototype.transform = function (object) {
        var _object = {};
        if (object) {
            if (Object.prototype.toString.call(object) === '[object Object]') {
                Object.keys(object).forEach(function (key, idx) {
                    var originalName = key;
                    var transformName = transform_fields_1.transformFields.toCamelCase(key);
                    _object[transformName] = object[originalName];
                });
            }
            else if (Object.prototype.toString.call(object) === '[object Array]') {
                _object = [];
                object.forEach(function (elm, idx) {
                    var transformName = transform_fields_1.transformFields.toCamelCase(elm);
                    _object.push(transformName);
                });
            }
        }
        return _object;
    };
    return TransformFields;
}());
exports.TransformFields = TransformFields;
//# sourceMappingURL=Transform.js.map