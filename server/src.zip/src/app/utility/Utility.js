"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Constants = require("../../config/constants/constants");
var Transform = (function () {
    function Transform(name) {
        if (name === void 0) { name = null; }
    }
    //To Camel Case
    Transform.prototype.transformToObject = function (object) {
        var _this = this;
        var _object = {};
        if (object) {
            if (Object.prototype.toString.call(object) === '[object Object]') {
                Object.keys(object).forEach(function (key, idx) {
                    var originalName = key;
                    var transformName = _this.toCamelCase(key);
                    _object[transformName] = object[originalName];
                });
            }
            else if (Object.prototype.toString.call(object) === '[object Array]') {
                _object = [];
                object.forEach(function (elm, idx) {
                    var transformName = _this.toCamelCase(elm);
                    _object.push(transformName);
                });
            }
        }
        return _object;
    };
    //To Snake Case
    Transform.prototype.transformToJSON = function (object) {
        var _this = this;
        var _object = {};
        if (object) {
            if (Object.prototype.toString.call(object) === '[object Object]') {
                Object.keys(object).forEach(function (key, idx) {
                    var originalName = key;
                    var transformName = _this.toSnakeCase(key);
                    _object[transformName] = object[originalName];
                });
            }
            else if (Object.prototype.toString.call(object) === '[object Array]') {
                _object = [];
                object.forEach(function (elm, idx) {
                    var transformName = _this.toSnakeCase(elm);
                    _object.push(transformName);
                });
            }
        }
        return _object;
    };
    Transform.prototype.toSnakeCase = function (source) {
        return source.replace(/\.?([A-Z])/g, function (x, y) { return "_" + y.toLowerCase(); }).replace(/^_/, "");
    };
    Transform.prototype.toCamelCase = function (source) {
        return source.replace(/(\_\w)/g, function (m) { return m[1].toUpperCase(); });
    };
    return Transform;
}());
exports.Transform = Transform;
var Options = (function () {
    function Options() {
    }
    Options.prototype.initOptions = function (input) {
        var query = input['query'] || {};
        var body = input['body'] || {};
        //Extract param from request body, query
        var _cond = {};
        _cond['filter'] = body['filter'] || {};
        _cond['sort'] = body['sort'] || {};
        var _fields = body['fields'] || [];
        var _limit = (+query['limit'] >= 0) ? +query['limit'] : Constants.PER_PAGE;
        var _page = query['page'] || 1;
        //Init param object
        var _options = {
            cond: _cond,
            fields: _fields,
            limit: _limit,
            page: _page
        };
        return _options;
    };
    return Options;
}());
exports.Options = Options;
//# sourceMappingURL=Utility.js.map