"use strict";
var InventoryItem = (function () {
    function InventoryItem(inventoryitem) {
        if (inventoryitem === void 0) { inventoryitem = {}; }
        this._inventoryItem = inventoryitem;
        if (!this._inventoryItem.inventoryItemCode) {
            var newId = new Date().getTime().toString();
            this._inventoryItem.inventoryItemCode = newId;
        }
    }
    Object.defineProperty(InventoryItem.prototype, "inventoryItemId", {
        get: function () {
            return this._inventoryItem.inventoryItemId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemCategory", {
        get: function () {
            return this._inventoryItem.inventoryItemCategory;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemName", {
        get: function () {
            return this._inventoryItem.inventoryItemName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemCode", {
        get: function () {
            return this._inventoryItem.inventoryItemCode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemDescription", {
        get: function () {
            return this._inventoryItem.inventoryItemDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemMinQuantity", {
        get: function () {
            return this._inventoryItem.inventoryItemMinQuantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemMaxQuantity", {
        get: function () {
            return this._inventoryItem.inventoryItemMaxQuantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemCostPrice", {
        get: function () {
            return this._inventoryItem.inventoryItemCostPrice;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemBaseUnit", {
        get: function () {
            return this._inventoryItem.inventoryItemBaseUnit;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemConversionUnit", {
        get: function () {
            return this._inventoryItem.inventoryItemConversionUnit;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemSpecification1", {
        get: function () {
            return this._inventoryItem.inventoryItemSpecification1;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemSpecification2", {
        get: function () {
            return this._inventoryItem.inventoryItemSpecification2;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemSpecification3", {
        get: function () {
            return this._inventoryItem.inventoryItemSpecification3;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemSpecification4", {
        get: function () {
            return this._inventoryItem.inventoryItemSpecification4;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "inventoryItemSpecification5", {
        get: function () {
            return this._inventoryItem.inventoryItemSpecification5;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "isActive", {
        get: function () {
            return this._inventoryItem.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "createdBy", {
        get: function () {
            return this._inventoryItem.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "updatedBy", {
        get: function () {
            return this._inventoryItem.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "createdAt", {
        get: function () {
            return this._inventoryItem.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItem.prototype, "updatedAt", {
        get: function () {
            return this._inventoryItem.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItem;
}());
Object.seal(InventoryItem);
module.exports = InventoryItem;
//# sourceMappingURL=InventoryItem.js.map