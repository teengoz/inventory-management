"use strict";
var Stock = (function () {
    function Stock(stock) {
        this._stock = stock;
    }
    Object.defineProperty(Stock.prototype, "stockId", {
        get: function () {
            return this._stock.stockId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "stockName", {
        get: function () {
            return this._stock.stockName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "stockCode", {
        get: function () {
            return this._stock.stockCode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "stockDescription", {
        get: function () {
            return this._stock.stockDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "stockAddress", {
        get: function () {
            return this._stock.stockAddress;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "isActive", {
        get: function () {
            return this._stock.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "createdBy", {
        get: function () {
            return this._stock.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "updatedBy", {
        get: function () {
            return this._stock.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "createdAt", {
        get: function () {
            return this._stock.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stock.prototype, "updatedAt", {
        get: function () {
            return this._stock.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return Stock;
}());
Object.seal(Stock);
module.exports = Stock;
//# sourceMappingURL=Stock.js.map