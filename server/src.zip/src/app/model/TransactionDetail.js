"use strict";
var TransactionDetail = (function () {
    function TransactionDetail(transactiondetail) {
        this._transactiondetail = transactiondetail;
    }
    Object.defineProperty(TransactionDetail.prototype, "transactionDetailId", {
        get: function () {
            return this._transactiondetail.transactionDetailId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "transaction", {
        get: function () {
            return this._transactiondetail.transaction;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "transactionType", {
        get: function () {
            return this._transactiondetail.transactionType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "inventoryItem", {
        get: function () {
            return this._transactiondetail.inventoryItem;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "stock", {
        get: function () {
            return this._transactiondetail.stock;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "secondStock", {
        get: function () {
            return this._transactiondetail.secondStock;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "unit", {
        get: function () {
            return this._transactiondetail.unit;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "quantity", {
        get: function () {
            return this._transactiondetail.quantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "price", {
        get: function () {
            return this._transactiondetail.price;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "baseUnit", {
        get: function () {
            return this._transactiondetail.baseUnit;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "conversionRate", {
        get: function () {
            return this._transactiondetail.conversionRate;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "conversionOperator", {
        get: function () {
            return this._transactiondetail.conversionOperator;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "realQuantity", {
        get: function () {
            return this._transactiondetail.realQuantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "lotNo", {
        get: function () {
            return this._transactiondetail.lotNo;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "createdBy", {
        get: function () {
            return this._transactiondetail.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "updatedBy", {
        get: function () {
            return this._transactiondetail.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "createdAt", {
        get: function () {
            return this._transactiondetail.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TransactionDetail.prototype, "updatedAt", {
        get: function () {
            return this._transactiondetail.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return TransactionDetail;
}());
Object.seal(TransactionDetail);
module.exports = TransactionDetail;
//# sourceMappingURL=TransactionDetail.js.map