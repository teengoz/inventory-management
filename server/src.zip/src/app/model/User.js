"use strict";
var crypto = require("crypto");
var jwt = require("jsonwebtoken");
var User = (function () {
    function User(user) {
        this._user = user;
    }
    Object.defineProperty(User.prototype, "_id", {
        get: function () {
            return this._user._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "username", {
        get: function () {
            return this._user.username;
        },
        set: function (newUsername) {
            this._user.username = newUsername;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "password", {
        get: function () {
            return this._user.password;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "hash", {
        get: function () {
            return this._user.hash;
        },
        set: function (newHash) {
            this._user.hash = newHash;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "salt", {
        get: function () {
            return this._user.salt;
        },
        set: function (newSalt) {
            this._user.salt = newSalt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "jobTitle", {
        get: function () {
            return this._user.jobTitle;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "fullName", {
        get: function () {
            return this._user.fullName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "email", {
        get: function () {
            return this._user.email;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "phone", {
        get: function () {
            return this._user.phone;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "address", {
        get: function () {
            return this._user.address;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "isActive", {
        get: function () {
            return this._user.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "createdAt", {
        get: function () {
            return this._user.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "updatedAt", {
        get: function () {
            return this._user.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    User.prototype.setPassword = function (password) {
        this.salt = crypto.randomBytes(16).toString('hex');
        this.hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64).toString('hex');
    };
    User.prototype.validPassword = function (password) {
        var hash = crypto.pbkdf2Sync(password, this.salt, 1000, 64).toString('hex');
        return this.hash == hash;
    };
    User.prototype.generateJwt = function () {
        var today = new Date();
        var exp = new Date(today);
        exp.setDate(today.getDate() + 1);
        return jwt.sign({
            _id: this._id,
            username: this.username,
            exp: parseInt((exp.getTime() / 1000).toString()),
        }, 'SECRET');
    };
    return User;
}());
Object.seal(User);
module.exports = User;
//# sourceMappingURL=User.js.map