"use strict";
var Transaction = (function () {
    function Transaction(transaction) {
        this._transaction = transaction;
    }
    Object.defineProperty(Transaction.prototype, "transactionId", {
        get: function () {
            return this._transaction.transactionId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "stakeholder", {
        get: function () {
            return this._transaction.stakeholder;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "transactionType", {
        get: function () {
            return this._transaction.transactionType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "transactionNo", {
        get: function () {
            return this._transaction.transactionNo;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "transactionDescription", {
        get: function () {
            return this._transaction.transactionDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "transactionTime", {
        get: function () {
            return this._transaction.transactionTime;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "isRecorded", {
        get: function () {
            return this._transaction.isRecorded;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "createdBy", {
        get: function () {
            return this._transaction.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "updatedBy", {
        get: function () {
            return this._transaction.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "createdAt", {
        get: function () {
            return this._transaction.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Transaction.prototype, "updatedAt", {
        get: function () {
            return this._transaction.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return Transaction;
}());
Object.seal(Transaction);
module.exports = Transaction;
//# sourceMappingURL=Transaction.js.map