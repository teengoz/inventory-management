"use strict";
var InventoryItemDiscount = (function () {
    function InventoryItemDiscount(inventoryitemdiscount) {
        this._inventoryitemdiscount = inventoryitemdiscount;
    }
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItemDiscountId", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItemDiscountId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItem", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItem;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItemDiscountMinQuantity", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItemDiscountMinQuantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItemDiscountMaxQuantity", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItemDiscountMaxQuantity;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItemDiscountValue", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItemDiscountValue;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "inventoryItemDiscountType", {
        get: function () {
            return this._inventoryitemdiscount.inventoryItemDiscountType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "isActive", {
        get: function () {
            return this._inventoryitemdiscount.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "createdBy", {
        get: function () {
            return this._inventoryitemdiscount.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "updatedBy", {
        get: function () {
            return this._inventoryitemdiscount.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "createdAt", {
        get: function () {
            return this._inventoryitemdiscount.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemDiscount.prototype, "updatedAt", {
        get: function () {
            return this._inventoryitemdiscount.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemDiscount;
}());
Object.seal(InventoryItemDiscount);
module.exports = InventoryItemDiscount;
//# sourceMappingURL=InventoryItemDiscount.js.map