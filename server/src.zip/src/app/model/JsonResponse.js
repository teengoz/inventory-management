"use strict";
var JsonResponse = (function () {
    function JsonResponse(_success, _data, _message, _errors, _meta) {
        if (_success === void 0) { _success = null; }
        if (_data === void 0) { _data = null; }
        if (_message === void 0) { _message = ''; }
        if (_errors === void 0) { _errors = null; }
        if (_meta === void 0) { _meta = null; }
        this.obj = {};
        this.obj = {};
        if (_success !== null) {
            this.obj.success = _success;
        }
        if (_message != '') {
            this.obj.message = _message;
        }
        if (_data) {
            this.obj.data = _data;
        }
        if (_errors) {
            this.obj.errors = _errors;
        }
        if (_meta) {
            this.obj.meta = _meta;
        }
    }
    JsonResponse.prototype.success = function (_success) {
        if (_success) {
            this.obj.success = _success;
        }
    };
    JsonResponse.prototype.message = function (_message) {
        if (_message != '') {
            this.obj.message = _message;
        }
    };
    JsonResponse.prototype.data = function (_data) {
        if (_data) {
            this.obj.data = _data;
        }
    };
    JsonResponse.prototype.errors = function (_errors) {
        if (_errors) {
            this.obj.errors = _errors;
        }
    };
    JsonResponse.prototype.meta = function (_meta) {
        if (_meta) {
            this.obj.meta = _meta;
        }
    };
    JsonResponse.prototype.return = function () {
        return this.obj;
    };
    return JsonResponse;
}());
Object.seal(JsonResponse);
module.exports = JsonResponse;
//# sourceMappingURL=JsonResponse.js.map