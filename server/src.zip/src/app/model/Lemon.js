"use strict";
var Lemon = (function () {
    function Lemon(lemon) {
        this._lemon = lemon;
    }
    Object.defineProperty(Lemon.prototype, "name", {
        get: function () {
            return this._lemon.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Lemon.prototype, "level", {
        get: function () {
            return this._lemon.level;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Lemon.prototype, "source", {
        get: function () {
            return this._lemon.source;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Lemon.prototype, "color", {
        get: function () {
            return this._lemon.color;
        },
        enumerable: true,
        configurable: true
    });
    return Lemon;
}());
Object.seal(Lemon);
module.exports = Lemon;
//# sourceMappingURL=Lemon.js.map