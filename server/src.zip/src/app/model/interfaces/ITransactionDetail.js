"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ITransactionDetail.js.map