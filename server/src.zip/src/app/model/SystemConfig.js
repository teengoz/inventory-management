"use strict";
var SystemConfig = (function () {
    function SystemConfig(systemconfig) {
        this._systemconfig = systemconfig;
    }
    Object.defineProperty(SystemConfig.prototype, "systemConfigId", {
        get: function () {
            return this._systemconfig.systemConfigId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigName", {
        get: function () {
            return this._systemconfig.systemConfigName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigFieldName", {
        get: function () {
            return this._systemconfig.systemConfigFieldName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigDescription", {
        get: function () {
            return this._systemconfig.systemConfigDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigInputType", {
        get: function () {
            return this._systemconfig.systemConfigInputType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "SystemConfigValue", {
        get: function () {
            return this._systemconfig.systemConfigValue;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigControlType", {
        get: function () {
            return this._systemconfig.systemConfigControlType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigLabelWidth", {
        get: function () {
            return this._systemconfig.systemConfigLabelWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigInputWidth", {
        get: function () {
            return this._systemconfig.systemConfigInputWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigRequired", {
        get: function () {
            return this._systemconfig.systemConfigRequired;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigInline", {
        get: function () {
            return this._systemconfig.systemConfigInline;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigOptionValues", {
        get: function () {
            return this._systemconfig.systemConfigOptionValues;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "systemConfigOrder", {
        get: function () {
            return this._systemconfig.systemConfigOrder;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "isActive", {
        get: function () {
            return this._systemconfig.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "createdBy", {
        get: function () {
            return this._systemconfig.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "updatedBy", {
        get: function () {
            return this._systemconfig.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "createdAt", {
        get: function () {
            return this._systemconfig.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SystemConfig.prototype, "updatedAt", {
        get: function () {
            return this._systemconfig.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return SystemConfig;
}());
Object.seal(SystemConfig);
module.exports = SystemConfig;
//# sourceMappingURL=SystemConfig.js.map