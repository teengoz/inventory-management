"use strict";
var Stakeholder = (function () {
    function Stakeholder(stakeholder) {
        this._stakeholder = stakeholder;
    }
    Object.defineProperty(Stakeholder.prototype, "stakeholderId", {
        get: function () {
            return this._stakeholder.stakeholderId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderType", {
        get: function () {
            return this._stakeholder.stakeholderType;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderCode", {
        get: function () {
            return this._stakeholder.stakeholderCode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderName", {
        get: function () {
            return this._stakeholder.stakeholderName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderDescription", {
        get: function () {
            return this._stakeholder.stakeholderDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderAddress", {
        get: function () {
            return this._stakeholder.stakeholderAddress;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderPhone1", {
        get: function () {
            return this._stakeholder.stakeholderPhone1;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderPhone2", {
        get: function () {
            return this._stakeholder.stakeholderPhone2;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderFax", {
        get: function () {
            return this._stakeholder.stakeholderFax;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderEmail", {
        get: function () {
            return this._stakeholder.stakeholderEmail;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderTaxcode", {
        get: function () {
            return this._stakeholder.stakeholderTaxcode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderAccountNumber", {
        get: function () {
            return this._stakeholder.stakeholderAccountNumber;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "stakeholderBank", {
        get: function () {
            return this._stakeholder.stakeholderBank;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "isActive", {
        get: function () {
            return this._stakeholder.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "createdBy", {
        get: function () {
            return this._stakeholder.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "updatedBy", {
        get: function () {
            return this._stakeholder.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "createdAt", {
        get: function () {
            return this._stakeholder.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Stakeholder.prototype, "updatedAt", {
        get: function () {
            return this._stakeholder.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return Stakeholder;
}());
Object.seal(Stakeholder);
module.exports = Stakeholder;
//# sourceMappingURL=Stakeholder.js.map