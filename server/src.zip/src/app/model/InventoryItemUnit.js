"use strict";
var InventoryItemUnit = (function () {
    function InventoryItemUnit(inventoryitemunit) {
        this._inventoryitemunit = inventoryitemunit;
    }
    Object.defineProperty(InventoryItemUnit.prototype, "inventoryItemUnitID", {
        get: function () {
            return this._inventoryitemunit.inventoryItemUnitId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "inventoryItemUnitAlias", {
        get: function () {
            return this._inventoryitemunit.inventoryItemUnitSymbol;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "inventoryItemUnitName", {
        get: function () {
            return this._inventoryitemunit.inventoryItemUnitName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "inventoryItemUnitDescription", {
        get: function () {
            return this._inventoryitemunit.inventoryItemUnitDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "createBy", {
        get: function () {
            return this._inventoryitemunit.createBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "updatedBy", {
        get: function () {
            return this._inventoryitemunit.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "createdBy", {
        get: function () {
            return this._inventoryitemunit.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemUnit.prototype, "updatedAt", {
        get: function () {
            return this._inventoryitemunit.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemUnit;
}());
Object.seal(InventoryItemUnit);
module.exports = InventoryItemUnit;
//# sourceMappingURL=InventoryItemUnit.js.map