"use strict";
var StakeholderType = (function () {
    function StakeholderType(stakeholdertype) {
        this._stakeholdertype = stakeholdertype;
    }
    Object.defineProperty(StakeholderType.prototype, "stakeholderTypeId", {
        get: function () {
            return this._stakeholdertype.stakeholderTypeId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "stakeholderTypeCode", {
        get: function () {
            return this._stakeholdertype.stakeholderTypeCode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "stakeholderTypeName", {
        get: function () {
            return this._stakeholdertype.stakeholderTypeName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "stakeholderTypeDescription", {
        get: function () {
            return this._stakeholdertype.stakeholderTypeDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "createdBy", {
        get: function () {
            return this._stakeholdertype.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "updatedBy", {
        get: function () {
            return this._stakeholdertype.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "createdAt", {
        get: function () {
            return this._stakeholdertype.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StakeholderType.prototype, "updatedAt", {
        get: function () {
            return this._stakeholdertype.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return StakeholderType;
}());
Object.seal(StakeholderType);
module.exports = StakeholderType;
//# sourceMappingURL=StakeholderType.js.map