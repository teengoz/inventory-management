"use strict";
var InventoryItemCategory = (function () {
    function InventoryItemCategory(inventoryitemcategory) {
        this._inventoryitemcategory = inventoryitemcategory;
    }
    Object.defineProperty(InventoryItemCategory.prototype, "inventoryItemCategoryId", {
        get: function () {
            return this._inventoryitemcategory.inventoryItemCategoryId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "inventoryItemCategoryName", {
        get: function () {
            return this._inventoryitemcategory.inventoryItemCategoryName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "inventoryItemCategoryCode", {
        get: function () {
            return this._inventoryitemcategory.inventoryItemCategoryCode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "inventoryItemCategoryDescription", {
        get: function () {
            return this._inventoryitemcategory.inventoryItemCategoryDescription;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "parentID", {
        get: function () {
            return this._inventoryitemcategory.parent;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "isActive", {
        get: function () {
            return this._inventoryitemcategory.isActive;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "createdBy", {
        get: function () {
            return this._inventoryitemcategory.createdBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "updatedBy", {
        get: function () {
            return this._inventoryitemcategory.updatedBy;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "createdAt", {
        get: function () {
            return this._inventoryitemcategory.createdAt;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(InventoryItemCategory.prototype, "updatedAt", {
        get: function () {
            return this._inventoryitemcategory.updatedAt;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemCategory;
}());
Object.seal(InventoryItemCategory);
module.exports = InventoryItemCategory;
//# sourceMappingURL=InventoryItemCategory.js.map