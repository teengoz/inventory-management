"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var InventoryItemDiscountSchema = require("../dataAccess/schemas/InventoryItemDiscountSchema");
var RepositoryBase = require("./BaseRepository");
var InventoryItemDiscountRepository = (function (_super) {
    __extends(InventoryItemDiscountRepository, _super);
    function InventoryItemDiscountRepository() {
        return _super.call(this, InventoryItemDiscountSchema) || this;
    }
    return InventoryItemDiscountRepository;
}(RepositoryBase));
Object.seal(InventoryItemDiscountRepository);
module.exports = InventoryItemDiscountRepository;
//# sourceMappingURL=InventoryItemDiscountRepository.js.map