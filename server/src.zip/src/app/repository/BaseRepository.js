"use strict";
var Constants = require("../../config/constants/constants");
var mongoose = require("mongoose");
var RepositoryBase = (function () {
    function RepositoryBase(schemaModel) {
        this.typeArray = ['$in', '=', 'search'];
        this._model = schemaModel;
    }
    RepositoryBase.prototype.create = function (item, callback) {
        var _item = item;
        this._model.create(_item, callback);
    };
    RepositoryBase.prototype.update = function (_id, item, callback) {
        mongoose.set('debug', true);
        var _item = item;
        if (_item['parent'] && (_id.toString() == _item['parent'].toString())) {
            callback('Error: _id == parent', null);
            return;
        }
        this._model.update({ _id: _id }, _item, callback);
    };
    RepositoryBase.prototype.delete = function (_id, callback) {
        this._model.remove({ _id: this.toObjectId(_id) }, function (err) { return callback(err, null); });
    };
    RepositoryBase.prototype.retrieve = function (callback, options) {
        mongoose.set('debug', true);
        var _page = options['page'] || 1;
        var _limit = (+options['limit'] >= 0) ? +options['limit'] : Constants.PER_PAGE;
        var _fields = options['fields'] || [];
        var _cond = options['cond'] || {};
        var _sort = _cond['sort'] || {};
        var _aggLookup = this.generateLookup();
        var _aggSort = (Object.keys(_sort).length) ? [{ $sort: _sort }] : [];
        var _aggLimit = (_limit > 0) ? [{ $limit: +_limit }] : [];
        var _aggSkip = [{ $skip: (_page - 1) * _limit }];
        var tempProject = this.generateProject(_fields);
        var _aggProject = (Object.keys(tempProject).length) ? [{ $project: tempProject }] : [];
        this._model
            .aggregate(_aggLookup.concat(_aggSort, _aggSkip, _aggLimit, _aggProject))
            .exec(callback);
    };
    RepositoryBase.prototype.find = function (callback, options) {
        mongoose.set('debug', true);
        var _cond = options['cond'] || {};
        var _filter = _cond['filter'] || {};
        var _regFilter = Object.assign({}, _filter);
        var _sort = _cond['sort'] || {};
        var _fields = options['fields'] || [];
        var _page = options['page'] || 1;
        var _limit = (+options['limit'] >= 0) ? +options['limit'] : Constants.PER_PAGE;
        if (!(_cond['type'] && this.typeArray.indexOf(_cond['type']) >= 0)) {
            for (var propName in _regFilter) {
                _regFilter[propName] = new RegExp(_regFilter[propName], "i");
            }
        }
        var _aggLookup = this.generateLookup();
        var _aggSort = (Object.keys(_sort).length) ? [{ $sort: _sort }] : [];
        var _aggLimit = (_limit > 0) ? [{ $limit: +_limit }] : [];
        var _aggFilter = (Object.keys(_regFilter).length) ? [{ $match: _regFilter }] : [];
        var _aggSkip = [{ $skip: (_page - 1) * _limit }];
        var tempProject = this.generateProject(_fields);
        var _aggProject = (Object.keys(tempProject).length) ? [{ $project: tempProject }] : [];
        this._model
            .aggregate(_aggLookup.concat(_aggFilter, _aggSort, _aggSkip, _aggLimit, _aggProject))
            .exec(callback);
    };
    RepositoryBase.prototype.findById = function (_id, callback) {
        mongoose.set('debug', true);
        var _aggLookup = this.generateLookup();
        var _aggFilter = [{ $match: { '_id': this.toObjectId(_id) } }];
        var tempProject = this.generateProject();
        var _aggProject = (Object.keys(tempProject).length) ? [{ $project: tempProject }] : [];
        this._model
            .aggregate(_aggLookup.concat(_aggFilter, _aggProject))
            .exec(function (error, result) {
            var item = (result[0]) ? result[0] : {};
            callback(error, item);
        });
    };
    RepositoryBase.prototype.getByIds = function (ids, callback) {
        mongoose.set('debug', true);
        var idObjects = [];
        for (var i = 0; i < ids.length; i++) {
            idObjects.push(this.toObjectId(ids[i]));
        }
        var _aggLookup = this.generateLookup();
        var _aggFilter = [{ $match: { '_id': { $in: idObjects } } }];
        var tempProject = this.generateProject();
        var _aggProject = (Object.keys(tempProject).length) ? [{ $project: tempProject }] : [];
        this._model
            .aggregate(_aggLookup.concat(_aggFilter, _aggProject))
            .exec(function (error, result) {
            var item = (result[0]) ? result[0] : {};
            callback(error, item);
        });
    };
    RepositoryBase.prototype.meta = function (callback, options) {
        //mongoose.set('debug', true);
        var _cond = options['cond'] || {};
        var _filter = _cond['filter'] || {};
        var _regFilter = Object.assign({}, _filter);
        var _sort = _cond['sort'] || {};
        var _page = options['page'] || 1;
        var _limit = (+options['limit'] >= 0) ? +options['limit'] : Constants.PER_PAGE;
        for (var propName in _filter) {
            _regFilter[propName] = new RegExp(_regFilter[propName], "i");
        }
        var _aggLookup = this.generateLookup();
        var _aggSort = (Object.keys(_sort).length) ? [{ $sort: _sort }] : [];
        var _aggLimit = (_limit > 0) ? [{ $limit: +_limit }] : [];
        var _aggFilter = (Object.keys(_regFilter).length) ? [{ $match: _regFilter }] : [];
        var _aggSkip = [{ $skip: (_page - 1) * _limit }];
        var _result = {};
        this._model
            .aggregate(_aggLookup.concat(_aggFilter, [
            {
                $count: 'count'
            }
        ]))
            .exec(function (error, result) {
            var length = (result[0]) ? result[0]['count'] : 0;
            _result['count'] = length;
            var resultDivision = length / _limit;
            var downwardDivision = Math.floor(length / _limit);
            var totalPage = (downwardDivision < resultDivision) ? (downwardDivision + 1) : downwardDivision;
            _result['totalPage'] = (totalPage != Infinity) ? totalPage : 1;
            _result['currentPage'] = _page;
            _result['query'] = _filter;
            _result['limit'] = _limit;
            callback(error, _result);
        });
    };
    RepositoryBase.prototype.generateLookup = function () {
        var _lookup = [];
        this._model.schema['options']['refs'].forEach(function (elm, idx) {
            var _temp = {
                $lookup: {
                    from: elm['model'],
                    localField: elm['key']['localField'],
                    foreignField: elm['key']['foreignField'],
                    as: elm['as'] || elm['key']['localField']
                }
            };
            _lookup.push(_temp);
        });
        return _lookup;
    };
    RepositoryBase.prototype.generateProject = function (selectFields) {
        var _project = {};
        var hiddenFields = this._model.schema['options']['hiddenFields'];
        var localFields = [];
        if (Object.prototype.toString.call(selectFields) === '[object Array]' && selectFields.length) {
            selectFields.forEach(function (elm) {
                if (hiddenFields.indexOf(elm) < 0) {
                    _project[elm] = 1;
                }
            });
        }
        else {
            var schemafFields = Object.keys(this._model.schema['obj']);
            this._model.schema['options']['refs'].forEach(function (elm, idx) {
                elm['fields'].forEach(function (fieldName) {
                    var _prefix = elm['as'] || elm['key']['localField'];
                    _project[_prefix + '.' + fieldName] = 1;
                    localFields.push(_prefix);
                });
            });
            schemafFields.forEach(function (elm) {
                if (hiddenFields.indexOf(elm) < 0 && localFields.indexOf(elm) < 0) {
                    _project[elm] = 1;
                }
            });
            // if (hiddenFields.indexOf('_id') && !_project.hasOwnProperty('_id')) {
            //     _project['_id'] = 0;
            // }
        }
        return _project;
    };
    RepositoryBase.prototype.toObjectId = function (_id) {
        return new mongoose.Types.ObjectId(_id);
    };
    return RepositoryBase;
}());
module.exports = RepositoryBase;
//# sourceMappingURL=BaseRepository.js.map