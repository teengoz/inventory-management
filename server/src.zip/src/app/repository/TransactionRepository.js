"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TransactionSchema = require("../dataAccess/schemas/TransactionSchema");
var RepositoryBase = require("./BaseRepository");
var mongoose = require("mongoose");
var TransactionRepository = (function (_super) {
    __extends(TransactionRepository, _super);
    function TransactionRepository() {
        return _super.call(this, TransactionSchema) || this;
    }
    TransactionRepository.prototype.update = function (_id, _item, callback) {
        var _this = this;
        mongoose.set('debug', true);
        this._model.findById(_id.toString(), function (error, result) {
            if (result.isRecorded && _item.isRecorded == undefined) {
                callback('Recorded', null);
            }
            else {
                _this._model.update({ _id: _id }, _item, callback);
            }
        });
    };
    return TransactionRepository;
}(RepositoryBase));
Object.seal(TransactionRepository);
module.exports = TransactionRepository;
//# sourceMappingURL=TransactionRepository.js.map