"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SystemConfigSchema = require("../dataAccess/schemas/SystemConfigSchema");
var RepositoryBase = require("./BaseRepository");
var SystemConfigRepository = (function (_super) {
    __extends(SystemConfigRepository, _super);
    function SystemConfigRepository() {
        return _super.call(this, SystemConfigSchema) || this;
    }
    return SystemConfigRepository;
}(RepositoryBase));
Object.seal(SystemConfigRepository);
module.exports = SystemConfigRepository;
//# sourceMappingURL=SystemConfigRepository.js.map