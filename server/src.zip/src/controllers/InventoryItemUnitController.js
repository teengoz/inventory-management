"use strict";
var InventoryItemUnitBusiness = require("../app/business/InventoryItemUnitBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var InventoryItemUnitController = (function () {
    function InventoryItemUnitController() {
    }
    InventoryItemUnitController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var unit = req.body;
            var inventoryItemUnitBusiness = new InventoryItemUnitBusiness();
            var userId = req['payload']['_id'];
            var userBusiness = new UserBusiness();
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                var userId = result['_id'];
                unit['createdBy'] = userId;
                inventoryItemUnitBusiness.create(unit, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.update = function (req, res) {
        console.log('UPDATE unit');
        try {
            var unit = req.body;
            var _id = req.params._id;
            var userId = req['payload']['_id'];
            var userBusiness = new UserBusiness();
            var inventoryItemUnitBusiness = new InventoryItemUnitBusiness();
            userBusiness.findById(userId, function (error, result) {
                var userId = result['_id'];
                unit['updatedBy'] = userId;
                inventoryItemUnitBusiness.update(_id, unit, function (error, result) {
                    if (error)
                        res.send({ "error": "error" });
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var inventoryItemUnitBusiness = new InventoryItemUnitBusiness();
            inventoryItemUnitBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.retrieve = function (req, res) {
        console.log('RETRIVE');
        try {
            var inventoryItemUnitBusiness_1 = new InventoryItemUnitBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            inventoryItemUnitBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    inventoryItemUnitBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            console.log(req.body);
            var inventoryItemUnitBusiness_2 = new InventoryItemUnitBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            inventoryItemUnitBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    inventoryItemUnitBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.hint = function (req, res) {
        console.log('HINT HINT');
        try {
            var inventoryItemUnitBusiness = new InventoryItemUnitBusiness();
            var optionsInstance = new Utility_1.Options();
            var _keyword = req.params._keyword || '';
            // let _filter = { 
            //     'inventoryItemCategoryId': { 
            //         $ne: 
            //     } 
            // }
            var _filter = (_keyword) ? { stakeholder_type_name: _keyword } : {};
            var _options = optionsInstance.initOptions({
                body: {
                    filter: _filter,
                    fields: [
                        'inventoryItemUnitId',
                        'inventoryItemUnitName'
                    ],
                    sort: { 'inventoryItemUnitName': 1 }
                },
                query: {
                    limit: 0
                }
            });
            inventoryItemUnitBusiness.query(function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            }, _options);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemUnitController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var inventoryItemUnitBusiness = new InventoryItemUnitBusiness();
            inventoryItemUnitBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return InventoryItemUnitController;
}());
module.exports = InventoryItemUnitController;
//# sourceMappingURL=InventoryItemUnitController.js.map