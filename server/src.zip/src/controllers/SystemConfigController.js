"use strict";
var SystemConfigBusiness = require("../app/business/SystemConfigBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var SystemConfigController = (function () {
    function SystemConfigController() {
    }
    SystemConfigController.prototype.create = function (req, res) {
        try {
            var systemConfigBusiness = new SystemConfigBusiness();
            var userBusiness = new UserBusiness();
            var item = req.body;
            var userId = req['payload']['_id'];
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                if (!error) {
                    var _userId = result['_id'];
                    item['createdBy'] = _userId;
                    systemConfigBusiness.create(item, function (error, result) {
                        if (error) {
                            console.log(error);
                            res.send({ "error": "error" });
                        }
                        else
                            res.send({ "success": true });
                    });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    SystemConfigController.prototype.update = function (req, res) {
        try {
            var systemConfigBusiness = new SystemConfigBusiness();
            var userBusiness = new UserBusiness();
            var items = req.body;
            var userId = req['payload']['_id'];
            var flag = true;
            userBusiness.findById(userId, function (error, result) {
                if (!error) {
                    var _userId_1 = result['_id'];
                    Object.keys(items).forEach(function (key, idx) {
                        var value = items[key];
                        systemConfigBusiness.findByFieldName(key, function (error, result) {
                            var configObj = result;
                            if (configObj) {
                                var configId = configObj['systemConfigId'];
                                configObj['systemConfigValue'] = value;
                                if (configObj['createdBy']) {
                                    delete configObj['createdBy'];
                                }
                                configObj['updatedBy'] = _userId_1;
                                systemConfigBusiness.update(configId, configObj, function (error, result) {
                                    if (error) {
                                        console.log(error);
                                        res.send({ "error": "error" });
                                    }
                                });
                            }
                            else {
                                res.send({ "error": "error" });
                            }
                        });
                    });
                    if (flag)
                        res.send({ "success": true });
                }
                else {
                    res.send({ "error": "error" });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    SystemConfigController.prototype.retrieveConfigList = function (req, res) {
        try {
            var systemConfigBusiness = new SystemConfigBusiness();
            //let list = req.body['list'];
            var list = req.body;
            if (Object.prototype.toString.call(list) === '[object Array]' && list.length > 0) {
                systemConfigBusiness.retrieveConfigList(list, function (error, result) {
                    if (error)
                        res.send({ "error": "error" });
                    else {
                        var jsonObj = new JsonResponse(true, result);
                        res.status(200).json(jsonObj.return());
                    }
                });
            }
            else {
                var jsonObj = new JsonResponse(true, {});
                res.status(200).json(jsonObj.return());
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return SystemConfigController;
}());
module.exports = SystemConfigController;
//# sourceMappingURL=SystemConfigController.js.map