"use strict";
var passport = require("passport");
var UserBusiness = require("./../app/business/UserBusiness");
var User = require("./../app/model/User");
var JsonResponse = require("../app/model/JsonResponse");
var AuthController = (function () {
    function AuthController() {
    }
    AuthController.prototype.authenticate = function (req, res, next) {
        if (!req.body.username || !req.body.password) {
            var errors = [];
            if (!req.body.username)
                errors.push('Username is required');
            if (!req.body.password)
                errors.push('Password is required');
            var jsonObj = new JsonResponse(false, '', null, errors);
            res.status(400).json(jsonObj.return());
            return;
        }
        passport.authenticate('local', function (err, user, info) {
            if (err) {
                return next(err);
            }
            if (user) {
                var _user = user;
                var currentUser = new User(_user);
                res.json({ token: currentUser.generateJwt() });
                return;
            }
            else {
                res.status(401).json(info);
                return;
            }
        })(req, res, next);
    };
    AuthController.prototype.checkAuth = function (req, res, next) {
        res.status(200).json({ success: true });
    };
    AuthController.prototype.getAuthenticatedUser = function (req, res, next) {
        var userBusiness = new UserBusiness();
        userBusiness.findById(req['payload']['_id'], function (error, result) {
            res.status(200).json({ 'result': result, 'payload': req['payload'] });
        });
    };
    return AuthController;
}());
module.exports = AuthController;
//# sourceMappingURL=AuthController.js.map