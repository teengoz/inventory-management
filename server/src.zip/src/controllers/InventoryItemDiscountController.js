"use strict";
var InventoryItemDiscountBusiness = require("./../app/business/InventoryItemDiscountBusiness");
var InventoryItemBusiness = require("../app/business/InventoryItemBusiness");
//import InventoryItemUnitBusiness = require('../app/business/InventoryItemUnitBusiness');
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var InventoryItemDiscountController = (function () {
    function InventoryItemDiscountController() {
        var _this = this;
        this.create = function (req, res) {
            console.log('CREATE');
            try {
                var item = req.body;
                var userId = req['payload']['_id'];
                var inventoryItemId = req.body['inventoryItem.inventoryItemId'];
                var inventoryItemDiscountBusiness = new InventoryItemDiscountBusiness();
                var inventoryItemBusiness = new InventoryItemBusiness();
                var userBusiness = new UserBusiness();
                userBusiness.findById(userId, function (error, result) {
                    var _userId = result['_id'];
                    item['createdBy'] = _userId;
                    _this.validForeignData(inventoryItemId, function (error, result) {
                        if (!error) {
                            item['inventoryItem'] = inventoryItemId;
                            inventoryItemDiscountBusiness.create(item, function (error, result) {
                                if (error || !result || !result.length) {
                                    console.log(error);
                                    res.send({ "error": "error" });
                                }
                                else
                                    res.send({ "success": true });
                            });
                        }
                        else {
                            res.send({ "error": "error" });
                        }
                    });
                });
            }
            catch (e) {
                console.log(e);
                res.send({ "error": "error in your request" });
            }
        };
        this.update = function (req, res) {
            console.log('UPDATE STOCK');
            try {
                var _id = req.params._id;
                var item = req.body;
                var userId = req['payload']['_id'];
                var inventoryItemId = req.body['inventoryItem.inventoryItemId'];
                var inventoryItemDiscountBusiness = new InventoryItemDiscountBusiness();
                var inventoryItemBusiness = new InventoryItemBusiness();
                var userBusiness = new UserBusiness();
                userBusiness.findById(userId, function (error, result) {
                    var _userId = result['_id'];
                    item['updatedBy'] = _userId;
                    _this.validForeignData(inventoryItemId, function (error, result) {
                        if (!error) {
                            item['inventoryItem'] = inventoryItemId;
                            inventoryItemDiscountBusiness.update(_id, item, function (error, result) {
                                if (error || !result || !result.length) {
                                    console.log(error);
                                    res.send({ "error": "error" });
                                }
                                else
                                    res.send({ "success": true });
                            });
                        }
                        else {
                            res.send({ "error": "error" });
                        }
                    });
                });
            }
            catch (e) {
                console.log(e);
                res.send({ "error": "error in your request" });
            }
        };
    }
    InventoryItemDiscountController.prototype.validForeignData = function (inventoryItemId, callback) {
        var inventoryItemDiscountBusiness = new InventoryItemDiscountBusiness();
        var inventoryItemBusiness = new InventoryItemBusiness();
        if (inventoryItemId) {
            inventoryItemBusiness.findById(inventoryItemId, function (error, result) {
                callback(error, result);
            });
        }
        else {
            callback('error', null);
        }
    };
    InventoryItemDiscountController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var inventoryItemDiscountBusiness = new InventoryItemDiscountBusiness();
            inventoryItemDiscountBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemDiscountController.prototype.retrieve = function (req, res) {
        try {
            var inventoryItemDiscountBusiness_1 = new InventoryItemDiscountBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            console.log('RETRIVE OPTIONS');
            inventoryItemDiscountBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    inventoryItemDiscountBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemDiscountController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var inventoryItemDiscountBusiness_2 = new InventoryItemDiscountBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            inventoryItemDiscountBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    inventoryItemDiscountBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemDiscountController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var inventoryItemDiscountBusiness = new InventoryItemDiscountBusiness();
            inventoryItemDiscountBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return InventoryItemDiscountController;
}());
module.exports = InventoryItemDiscountController;
//# sourceMappingURL=InventoryItemDiscountController.js.map