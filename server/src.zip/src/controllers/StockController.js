"use strict";
var StockBusiness = require("./../app/business/StockBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var StockController = (function () {
    function StockController() {
    }
    StockController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var item = req.body;
            var stockBusiness = new StockBusiness();
            var userId = req['payload']['_id'];
            var userBusiness = new UserBusiness();
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                var userId = result['_id'];
                item['createdBy'] = userId;
                stockBusiness.create(item, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StockController.prototype.update = function (req, res) {
        console.log('UPDATE STOCK');
        try {
            var stock = req.body;
            var _id = req.params._id;
            var userId = req['payload']['_id'];
            var stockBusiness = new StockBusiness();
            var userBusiness = new UserBusiness();
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                var userId = result['_id'];
                stock['updatedBy'] = userId;
                stockBusiness.update(_id, stock, function (error, result) {
                    if (error)
                        res.send({ "error": "error" });
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StockController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var stockBusiness = new StockBusiness();
            stockBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StockController.prototype.retrieve = function (req, res) {
        try {
            var stockBusiness_1 = new StockBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            console.log('RETRIVE OPTIONS');
            console.log(_options_1);
            stockBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    stockBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StockController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var stockBusiness_2 = new StockBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            stockBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    stockBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StockController.prototype.search = function (req, res) {
        console.log('STOCK SEARCH');
        try {
            var keyword = req.params._keyword;
            var _keyword = keyword || '';
            var stockBusiness = new StockBusiness();
            stockBusiness.search(_keyword, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    ;
    StockController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var stockBusiness = new StockBusiness();
            stockBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return StockController;
}());
module.exports = StockController;
//# sourceMappingURL=StockController.js.map