"use strict";
var TransactionBusiness = require("./../app/business/TransactionBusiness");
var InventoryItemCategoryBusiness = require("../app/business/InventoryItemCategoryBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var TransactionController = (function () {
    function TransactionController() {
    }
    TransactionController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var transactionBusiness = new TransactionBusiness();
            transactionBusiness.create(req, function (error, result) {
                if (error) {
                    //console.log(error);
                    res.send({ "error": "error" });
                }
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.record = function (req, res) {
        console.log('RECORD');
        try {
            var transactionBusiness = new TransactionBusiness();
            var _id = req.params._id;
            var _record = req.params._record;
            transactionBusiness.record(_id, _record, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.update = function (req, res) {
        console.log('UPDATE');
        try {
            var transactionBusiness = new TransactionBusiness();
            transactionBusiness.updateByRequestData(req, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.validForeignData = function (inventoryItemCategoryId, callback) {
        var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
        var userBusiness = new UserBusiness();
        if (inventoryItemCategoryId) {
            inventoryItemCategoryBusiness.findById(inventoryItemCategoryId, function (error, result) {
                callback(error, result);
            });
        }
        else {
            callback('error', null);
        }
    };
    TransactionController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var transactionBusiness = new TransactionBusiness();
            transactionBusiness.delete(_id, function (error) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.retrieve = function (req, res) {
        try {
            var transactionBusiness_1 = new TransactionBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            console.log('RETRIVE OPTIONS');
            transactionBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    transactionBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var transactionBusiness_2 = new TransactionBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            transactionBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    transactionBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    TransactionController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var transactionBusiness = new TransactionBusiness();
            transactionBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return TransactionController;
}());
module.exports = TransactionController;
//# sourceMappingURL=TransactionController.js.map