"use strict";
var LemonBusiness = require("./../app/business/LemonBusiness");
var LemonController = (function () {
    function LemonController() {
    }
    LemonController.prototype.create = function (req, res) {
        try {
            var lemon = req.body;
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.create(lemon, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": "success" });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    LemonController.prototype.debugCreate = function (req, res) {
        try {
            var lemon = {
                name: 'Micheal Lemon',
                level: 2,
                color: 'RED',
                source: 'US'
            };
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.create(lemon, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": "success" });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    LemonController.prototype.update = function (req, res) {
        try {
            var lemon = req.body;
            var _id = req.params._id;
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.update(_id, lemon, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": "success" });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    LemonController.prototype.delete = function (req, res) {
        try {
            var _id = req.params._id;
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": "success" });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    LemonController.prototype.retrieve = function (req, res) {
        try {
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send(result);
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    LemonController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var lemonBusiness = new LemonBusiness();
            lemonBusiness.findById(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send(result);
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return LemonController;
}());
module.exports = LemonController;
//# sourceMappingURL=LemonController.js.map