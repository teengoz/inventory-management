"use strict";
var InventoryItemBusiness = require("./../app/business/InventoryItemBusiness");
var InventoryItemCategoryBusiness = require("../app/business/InventoryItemCategoryBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var InventoryItemController = (function () {
    function InventoryItemController() {
        this.update = function (req, res) {
            console.log('UPDATE');
            try {
                var inventoryItemBusiness = new InventoryItemBusiness();
                inventoryItemBusiness.updateItem(req, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else
                        res.send({ "success": true });
                });
            }
            catch (e) {
                console.log(e);
                res.send({ "error": "error in your request" });
            }
        };
    }
    InventoryItemController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.create(req, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.validForeignData = function (inventoryItemCategoryId, callback) {
        var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
        var userBusiness = new UserBusiness();
        if (inventoryItemCategoryId) {
            inventoryItemCategoryBusiness.findById(inventoryItemCategoryId, function (error, result) {
                callback(error, result);
            });
        }
        else {
            callback('error', null);
        }
    };
    InventoryItemController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.retrieve = function (req, res) {
        try {
            var inventoryItemBusiness_1 = new InventoryItemBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            console.log('RETRIVE OPTIONS');
            inventoryItemBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    inventoryItemBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var inventoryItemBusiness_2 = new InventoryItemBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            inventoryItemBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    inventoryItemBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.search = function (req, res) {
        try {
            var keyword = req.params._keyword;
            var _keyword = keyword || '';
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.search(_keyword, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    ;
    InventoryItemController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.getQuantity = function (req, res) {
        try {
            var _id = req.params._id;
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.getQuantity(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemController.prototype.findCode = function (req, res) {
        try {
            var _code = req.params._code;
            var inventoryItemBusiness = new InventoryItemBusiness();
            inventoryItemBusiness.findCode(_code, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var item = result;
                    var jsonObj = new JsonResponse(true, item);
                    res.status(200).json(jsonObj.return());
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return InventoryItemController;
}());
module.exports = InventoryItemController;
//# sourceMappingURL=InventoryItemController.js.map