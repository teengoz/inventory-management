"use strict";
var StakeholderTypeBusiness = require("../app/business/StakeholderTypeBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var StakeholderTypeController = (function () {
    function StakeholderTypeController() {
    }
    StakeholderTypeController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            var userBusiness = new UserBusiness();
            var item = req.body;
            var userId = req['payload']['_id'];
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                var userId = result['_id'];
                item['createdBy'] = userId;
                stakeholderTypeBusiness.create(item, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.update = function (req, res) {
        console.log('UPDATE');
        try {
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            var userBusiness = new UserBusiness();
            var item = req.body;
            var _id = req.params._id;
            var userId = req['payload']['_id'];
            userBusiness.findById(req['payload']['_id'], function (error, result) {
                var userId = result['_id'];
                item['updatedBy'] = userId;
                stakeholderTypeBusiness.update(_id, item, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else
                        res.send({ "success": true });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            stakeholderTypeBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.retrieve = function (req, res) {
        try {
            var stakeholderTypeBusiness_1 = new StakeholderTypeBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            stakeholderTypeBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    stakeholderTypeBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var stakeholderTypeBusiness_2 = new StakeholderTypeBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            stakeholderTypeBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    stakeholderTypeBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.hint = function (req, res) {
        try {
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            var optionsInstance = new Utility_1.Options();
            var _keyword = req.params._keyword || '';
            var _filter = (_keyword) ? { 'stakeholderTypeName': _keyword } : {};
            var _options = optionsInstance.initOptions({
                body: {
                    filter: _filter,
                    fields: [
                        'stakeholderTypeId',
                        'stakeholderTypeName'
                    ],
                    sort: { 'stakeholderTypeName': 1 }
                },
                query: {
                    limit: 0
                }
            });
            stakeholderTypeBusiness.query(function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            }, _options);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            stakeholderTypeBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return StakeholderTypeController;
}());
module.exports = StakeholderTypeController;
//# sourceMappingURL=StakeholderTypeController.js.map