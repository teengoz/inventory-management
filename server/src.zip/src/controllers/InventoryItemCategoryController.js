"use strict";
var InventoryItemCategoryBusiness = require("../app/business/InventoryItemCategoryBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var InventoryItemCategoryController = (function () {
    function InventoryItemCategoryController() {
    }
    InventoryItemCategoryController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var item = req.body;
            var userId = req['payload']['_id'];
            var inventoryItemCategoryId = req.body['parent.inventoryItemCategoryId'];
            var userBusiness = new UserBusiness();
            var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
            userBusiness.findById(userId, function (error, result) {
                var _userId = result['_id'];
                item['createdBy'] = _userId;
                if (inventoryItemCategoryId) {
                    inventoryItemCategoryBusiness.findById(inventoryItemCategoryId, function (error, result) {
                        if (error || !result) {
                            res.send({ "error": "error" });
                        }
                        else {
                            var _inventoryItemCategoryId = result['_id'];
                            item['parent'] = _inventoryItemCategoryId;
                            inventoryItemCategoryBusiness.create(item, function (error, result) {
                                if (error) {
                                    console.log(error);
                                    res.send({ "error": "error" });
                                }
                                else
                                    res.send({ "success": true });
                            });
                        }
                    });
                }
                else {
                    inventoryItemCategoryBusiness.create(item, function (error, result) {
                        if (error) {
                            console.log(error);
                            res.send({ "error": "error" });
                        }
                        else
                            res.send({ "success": true });
                    });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.update = function (req, res) {
        console.log('UPDATE');
        try {
            var _id = req.params._id;
            var item = req.body;
            var inventoryItemCategoryId = req.body['parent.inventoryItemCategoryId'];
            delete item['parent.inventoryItemCategoryId'];
            var userId = req['payload']['_id'];
            var userBusiness = new UserBusiness();
            var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
            userBusiness.findById(userId, function (error, result) {
                var _userId = result['_id'];
                item['updatedBy'] = _userId;
                if (inventoryItemCategoryId) {
                    inventoryItemCategoryBusiness.findById(inventoryItemCategoryId, function (error, result) {
                        if (error || !result) {
                            console.log(error);
                            res.send({ "error": "error" });
                        }
                        else {
                            var _inventoryItemCategoryId = result['_id'];
                            item['parent'] = _inventoryItemCategoryId;
                            inventoryItemCategoryBusiness.update(_id, item, function (error, result) {
                                if (error) {
                                    console.log(error);
                                    res.send({ "error": "error" });
                                }
                                else
                                    res.send({ "success": true });
                            });
                        }
                    });
                }
                else {
                    console.log(item);
                    item['parent'] = null;
                    inventoryItemCategoryBusiness.update(_id, item, function (error, result) {
                        if (error) {
                            console.log(error);
                            res.send({ "error": "error" });
                        }
                        else
                            res.send({ "success": true });
                    });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
            inventoryItemCategoryBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.retrieve = function (req, res) {
        try {
            var inventoryItemCategoryBusiness_1 = new InventoryItemCategoryBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            inventoryItemCategoryBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    inventoryItemCategoryBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var inventoryItemCategoryBusiness_2 = new InventoryItemCategoryBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            inventoryItemCategoryBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    inventoryItemCategoryBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.hint = function (req, res) {
        try {
            var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
            var optionsInstance = new Utility_1.Options();
            var _keyword = req.params._keyword || '';
            // let _filter = {
            //     'inventoryItemCategoryId': {
            //         $ne:
            //     }
            // }
            var _filter = (_keyword) ? { stakeholder_type_name: _keyword } : {};
            var _options = optionsInstance.initOptions({
                body: {
                    filter: _filter,
                    fields: [
                        'inventoryItemCategoryId',
                        'inventoryItemCategoryName'
                    ],
                    sort: { 'inventoryItemCategoryName': 1 }
                },
                query: {
                    limit: 0
                }
            });
            inventoryItemCategoryBusiness.query(function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            }, _options);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    InventoryItemCategoryController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var inventoryItemCategoryBusiness = new InventoryItemCategoryBusiness();
            inventoryItemCategoryBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return InventoryItemCategoryController;
}());
module.exports = InventoryItemCategoryController;
//# sourceMappingURL=InventoryItemCategoryController.js.map