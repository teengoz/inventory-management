"use strict";
var StakeholderBusiness = require("../app/business/StakeholderBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var StakeholderTypeBusiness = require("../app/business/StakeholderTypeBusiness");
var JsonResponse = require("../app/model/JsonResponse");
var Utility_1 = require("../app/utility/Utility");
var StakeholderTypeController = (function () {
    function StakeholderTypeController() {
    }
    StakeholderTypeController.prototype.create = function (req, res) {
        console.log('CREATE');
        try {
            var item = req.body;
            var stakeholderBusiness = new StakeholderBusiness();
            var userId = req['payload']['_id'];
            var stakeholderTypeId = req.body['stakeholderType.stakeholderTypeId'];
            var userBusiness = new UserBusiness();
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            userBusiness.findById(userId, function (error, result) {
                var _userId = result['_id'];
                item['createdBy'] = _userId;
                item['stakeholderType'] = stakeholderTypeId;
                stakeholderTypeBusiness.findById(stakeholderTypeId, function (error, result) {
                    if (error || !result) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else {
                        stakeholderBusiness.create(item, function (error, result) {
                            if (error) {
                                console.log(error);
                                res.send({ "error": "error" });
                            }
                            else
                                res.send({ "success": true });
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.update = function (req, res) {
        console.log('UPDATE');
        try {
            var _id = req.params._id;
            var item = req.body;
            var stakeholderTypeId = req.body['stakeholderType.stakeholderTypeId'];
            if (item['stakeholderType.stakeholderTypeId']) {
                delete item['stakeholderType.stakeholderTypeId'];
            }
            var userId = req['payload']['_id'];
            var stakeholderBusiness = new StakeholderBusiness();
            var userBusiness = new UserBusiness();
            var stakeholderTypeBusiness = new StakeholderTypeBusiness();
            userBusiness.findById(userId, function (error, result) {
                var _userId = result['_id'];
                item['updatedBy'] = _userId;
                item['stakeholderType'] = stakeholderTypeId;
                stakeholderTypeBusiness.findById(stakeholderTypeId, function (error, result) {
                    if (error || !result) {
                        console.log(error);
                        res.send({ "error": "error" });
                    }
                    else {
                        stakeholderBusiness.update(_id, item, function (error, result) {
                            if (error) {
                                console.log(error);
                                res.send({ "error": "error" });
                            }
                            else
                                res.send({ "success": true });
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.delete = function (req, res) {
        console.log('DELETE');
        try {
            var _id = req.params._id;
            var stakeholderTypeBusiness = new StakeholderBusiness();
            stakeholderTypeBusiness.delete(_id, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else
                    res.send({ "success": true });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.retrieve = function (req, res) {
        console.log('RETRIVE');
        try {
            var stakeholderTypeBusiness_1 = new StakeholderBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_1 = optionsInstance.initOptions({
                query: req.query
            });
            stakeholderTypeBusiness_1.retrieve(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_1 = new JsonResponse(true, result);
                    stakeholderTypeBusiness_1.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_1.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_1.return());
                    }, _options_1);
                }
            }, _options_1);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.query = function (req, res) {
        console.log('QUERY');
        try {
            var stakeholderTypeBusiness_2 = new StakeholderBusiness();
            var optionsInstance = new Utility_1.Options();
            var _options_2 = optionsInstance.initOptions({
                query: req.query,
                body: req.body
            });
            stakeholderTypeBusiness_2.query(function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    var jsonObj_2 = new JsonResponse(true, result);
                    stakeholderTypeBusiness_2.meta(function (error, result) {
                        var _meta = {
                            total: result.count,
                            total_page: result.totalPage,
                            current_page: result.currentPage,
                            query: result.query,
                            limit: result.limit
                        };
                        jsonObj_2.meta(_meta);
                        if (error)
                            res.send({ "error": "error" });
                        else
                            // setTimeout(() => {
                            //     res.status(200).json(jsonObj.return());
                            // }, 6000);
                            res.status(200).json(jsonObj_2.return());
                    }, _options_2);
                }
            }, _options_2);
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    StakeholderTypeController.prototype.search = function (req, res) {
        console.log('SEARCH');
        try {
            var keyword = req.params._keyword;
            var _keyword = keyword || '';
            var stakeholderBusiness = new StakeholderBusiness();
            stakeholderBusiness.search(_keyword, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    ;
    StakeholderTypeController.prototype.findById = function (req, res) {
        try {
            var _id = req.params._id;
            var stakeholderTypeBusiness = new StakeholderBusiness();
            stakeholderTypeBusiness.findById(_id, function (error, result) {
                var jsonObj = new JsonResponse(true, result);
                if (error)
                    res.send({ "error": "error" });
                else
                    res.status(200).json(jsonObj.return());
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return StakeholderTypeController;
}());
module.exports = StakeholderTypeController;
//# sourceMappingURL=StakeholderController.js.map