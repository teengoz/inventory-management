"use strict";
var express = require("express");
var StakeholderTypeController = require("../../controllers/StakeholderTypeController");
var router = express.Router();
var StakeholderTypeRoutes = (function () {
    function StakeholderTypeRoutes() {
        this._stakeholderTypeController = new StakeholderTypeController();
    }
    Object.defineProperty(StakeholderTypeRoutes.prototype, "routes", {
        get: function () {
            var controller = this._stakeholderTypeController;
            router.get("/", controller.retrieve);
            router.get("/hint/:_keyword", controller.hint);
            router.get("/hint/", controller.hint);
            router.get("/:_id", controller.findById);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return StakeholderTypeRoutes;
}());
Object.seal(StakeholderTypeRoutes);
module.exports = StakeholderTypeRoutes;
//# sourceMappingURL=StakeholderTypeRoutes.js.map