"use strict";
var express = require("express");
var UserController = require("./../../controllers/UserController");
var User = require("../../app/model/User");
//////////////////////////////////////////////
//Debug code for Add New and Authenticate User
var UserBusiness = require("../../app/business/UserBusiness");
var router = express.Router();
var UserRoutes = (function () {
    function UserRoutes() {
        this._userController = new UserController();
    }
    Object.defineProperty(UserRoutes.prototype, "routes", {
        get: function () {
            var controller = this._userController;
            router.get("/users", controller.retrieve);
            router.post("/users", controller.create);
            //router.get("/newuser", controller.debugCreate);
            router.put("/users/:_id", controller.update);
            router.get("/users/:_id", controller.findById);
            router.delete("/users/:_id", controller.delete);
            //////////////////////////////////////////////
            //Debug code for Add New and Authenticate User
            router.post("/users/register", function (req, res, next) {
                if (!req.body.username || !req.body.password) {
                    return res.status(400).json({ message: 'Please fill out all fields' });
                }
                var _user = {
                    username: '',
                    hash: '',
                    salt: ''
                };
                var user = new User(_user);
                user.username = req.body.username;
                user.setPassword(req.body.password);
                try {
                    var _user_1 = {
                        username: user.username,
                        hash: user.hash,
                        salt: user.salt
                    };
                    var userBusiness = new UserBusiness();
                    userBusiness.create(_user_1, function (error, result) {
                        if (error)
                            res.send({ "error": "error" });
                        else
                            res.json({ token: user.generateJwt() });
                    });
                }
                catch (e) {
                    console.log(e);
                    res.send({ "error": "error in your request" });
                }
            });
            //////////////////////////////////////////////
            //////////////////////////////////////////////
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return UserRoutes;
}());
Object.seal(UserRoutes);
module.exports = UserRoutes;
//# sourceMappingURL=UserRoutes.js.map