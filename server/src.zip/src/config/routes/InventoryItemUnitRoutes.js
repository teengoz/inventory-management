"use strict";
var express = require("express");
var InventoryItemUnitController = require("../../controllers/InventoryItemUnitController");
var router = express.Router();
var InventoryItemUnitRoutes = (function () {
    function InventoryItemUnitRoutes() {
        this._inventoryItemUnitController = new InventoryItemUnitController();
    }
    Object.defineProperty(InventoryItemUnitRoutes.prototype, "routes", {
        get: function () {
            var controller = this._inventoryItemUnitController;
            router.get("/", controller.retrieve);
            router.get("/hint/:_keyword", controller.hint);
            router.get("/hint/", controller.hint);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/:_id", controller.findById);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemUnitRoutes;
}());
Object.seal(InventoryItemUnitRoutes);
module.exports = InventoryItemUnitRoutes;
//# sourceMappingURL=InventoryItemUnitRoutes.js.map