"use strict";
var express = require("express");
var jwt = require("express-jwt");
var AuthController = require("../../controllers/AuthController");
var router = express.Router();
var auth = jwt({ secret: 'SECRET', userProperty: 'payload' });
var AuthRoutes = (function () {
    function AuthRoutes() {
        this._authController = new AuthController();
    }
    Object.defineProperty(AuthRoutes.prototype, "routes", {
        get: function () {
            var controller = this._authController;
            router.get("/", auth, controller.getAuthenticatedUser);
            router.post("/", controller.authenticate);
            router.get("/check", auth, controller.checkAuth);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return AuthRoutes;
}());
Object.seal(AuthRoutes);
module.exports = AuthRoutes;
//# sourceMappingURL=AuthRoutes.js.map