"use strict";
var express = require("express");
var InventoryItemCategoryController = require("../../controllers/InventoryItemCategoryController");
var router = express.Router();
var InventoryItemCategoryRoutes = (function () {
    function InventoryItemCategoryRoutes() {
        this._inventoryItemCategoryController = new InventoryItemCategoryController();
    }
    Object.defineProperty(InventoryItemCategoryRoutes.prototype, "routes", {
        get: function () {
            var controller = this._inventoryItemCategoryController;
            router.get("/", controller.retrieve);
            router.get("/hint/:_keyword", controller.hint);
            router.get("/hint/", controller.hint);
            router.get("/:_id", controller.findById);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemCategoryRoutes;
}());
Object.seal(InventoryItemCategoryRoutes);
module.exports = InventoryItemCategoryRoutes;
//# sourceMappingURL=InventoryItemCategoryRoutes.js.map