"use strict";
var express = require("express");
var StakeholderController = require("../../controllers/StakeholderController");
var router = express.Router();
var StakeholderRoutes = (function () {
    function StakeholderRoutes() {
        this._stakeholderController = new StakeholderController();
    }
    Object.defineProperty(StakeholderRoutes.prototype, "routes", {
        get: function () {
            var controller = this._stakeholderController;
            router.get("/", controller.retrieve);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/search", controller.search);
            router.get("/search/:_keyword", controller.search);
            router.get("/:_id", controller.findById);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return StakeholderRoutes;
}());
Object.seal(StakeholderRoutes);
module.exports = StakeholderRoutes;
//# sourceMappingURL=StakeholderRoutes.js.map