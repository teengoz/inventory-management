/**
 * Created by Moiz.Kachwala on 15-06-2016.
 */
"use strict";
var express = require("express");
var HeroController = require("./../../controllers/HeroController");
var router = express.Router();
var HeroRoutes = (function () {
    function HeroRoutes() {
        this._heroController = new HeroController();
    }
    Object.defineProperty(HeroRoutes.prototype, "routes", {
        get: function () {
            var controller = this._heroController;
            router.get("/", controller.retrieve);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/:_id", controller.findById);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return HeroRoutes;
}());
Object.seal(HeroRoutes);
module.exports = HeroRoutes;
//# sourceMappingURL=HeroRoutes.js.map