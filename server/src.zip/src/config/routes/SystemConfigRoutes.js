"use strict";
var express = require("express");
var SystemConfigController = require("../../controllers/SystemConfigController");
var router = express.Router();
var SystemConfigRoutes = (function () {
    function SystemConfigRoutes() {
        this._systemConfigController = new SystemConfigController();
    }
    Object.defineProperty(SystemConfigRoutes.prototype, "routes", {
        get: function () {
            var controller = this._systemConfigController;
            router.post('/create', controller.create);
            router.post('/getConfigs', controller.retrieveConfigList);
            router.put('/updateConfigs', controller.update);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return SystemConfigRoutes;
}());
Object.seal(SystemConfigRoutes);
module.exports = SystemConfigRoutes;
//# sourceMappingURL=SystemConfigRoutes.js.map