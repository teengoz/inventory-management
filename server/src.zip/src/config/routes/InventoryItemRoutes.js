"use strict";
var express = require("express");
var InventoryItemController = require("../../controllers/InventoryItemController");
var router = express.Router();
var InventoryItemRoutes = (function () {
    function InventoryItemRoutes() {
        this._inventoryItemController = new InventoryItemController();
    }
    Object.defineProperty(InventoryItemRoutes.prototype, "routes", {
        get: function () {
            var controller = this._inventoryItemController;
            router.get("/", controller.retrieve);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/search", controller.search);
            router.get("/search/:_keyword", controller.search);
            router.get("/:_id", controller.findById);
            router.get("/:_id/quantity", controller.getQuantity);
            router.get("/code/:_code", controller.findCode);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemRoutes;
}());
Object.seal(InventoryItemRoutes);
module.exports = InventoryItemRoutes;
//# sourceMappingURL=InventoryItemRoutes.js.map