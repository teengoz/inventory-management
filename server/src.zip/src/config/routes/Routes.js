"use strict";
var express = require("express");
var jwt = require("express-jwt");
var HeroRoutes = require("../routes/HeroRoutes");
var LemonRoutes = require("../routes/LemonRoutes");
var UserRoutes = require("../routes/UserRoutes");
var AuthRoutes = require("../routes/AuthRoutes");
var StockRoutes = require("../routes/StockRoutes");
var InventoryItemUnitRoutes = require("../routes/InventoryItemUnitRoutes");
var StakeholderTypeRoutes = require("../routes/StakeholderTypeRoutes");
var StakeholderRoutes = require("../routes/StakeholderRoutes");
var InventoryItemCategoryRoutes = require("../routes/InventoryItemCategoryRoutes");
var SystemConfigRoutes = require("../routes/SystemConfigRoutes");
var InventoryItemRoutes = require("../routes/InventoryItemRoutes");
var InventoryItemDiscountRoutes = require("../routes/InventoryItemDiscountRoutes");
var TransactionRoutes = require("../routes/TransactionRoutes");
var app = express();
var auth = jwt({ secret: 'SECRET', userProperty: 'payload' });
var Routes = (function () {
    function Routes() {
    }
    Object.defineProperty(Routes.prototype, "routes", {
        get: function () {
            app.use("/auth", new AuthRoutes().routes);
            app.use("/heroes", auth, new HeroRoutes().routes);
            app.use("/stocks", auth, new StockRoutes().routes);
            app.use("/units", auth, new InventoryItemUnitRoutes().routes);
            app.use("/stakeholder-types", auth, new StakeholderTypeRoutes().routes);
            app.use("/stakeholders", auth, new StakeholderRoutes().routes);
            app.use("/item-categories", auth, new InventoryItemCategoryRoutes().routes);
            app.use("/config", auth, new SystemConfigRoutes().routes);
            app.use("/items", auth, new InventoryItemRoutes().routes);
            app.use("/item-discounts", auth, new InventoryItemDiscountRoutes().routes);
            app.use("/transactions", auth, new TransactionRoutes().routes);
            app.use("/", new LemonRoutes().routes);
            app.use("/", new UserRoutes().routes);
            return app;
        },
        enumerable: true,
        configurable: true
    });
    return Routes;
}());
module.exports = Routes;
//# sourceMappingURL=Routes.js.map