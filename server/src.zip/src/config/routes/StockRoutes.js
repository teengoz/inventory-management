"use strict";
var express = require("express");
var StockController = require("../../controllers/StockController");
var router = express.Router();
var StockRoutes = (function () {
    function StockRoutes() {
        this._stockController = new StockController();
    }
    Object.defineProperty(StockRoutes.prototype, "routes", {
        get: function () {
            var controller = this._stockController;
            router.get("/", controller.retrieve);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/search", controller.search);
            router.get("/search/:_keyword", controller.search);
            router.get("/:_id", controller.findById);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return StockRoutes;
}());
Object.seal(StockRoutes);
module.exports = StockRoutes;
//# sourceMappingURL=StockRoutes.js.map