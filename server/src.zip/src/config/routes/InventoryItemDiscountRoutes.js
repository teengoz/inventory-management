"use strict";
var express = require("express");
var InventoryItemDiscountController = require("../../controllers/InventoryItemDiscountController");
var router = express.Router();
var InventoryItemDiscountRoutes = (function () {
    function InventoryItemDiscountRoutes() {
        this._inventoryItemDiscountController = new InventoryItemDiscountController();
    }
    Object.defineProperty(InventoryItemDiscountRoutes.prototype, "routes", {
        get: function () {
            var controller = this._inventoryItemDiscountController;
            router.get("/", controller.retrieve);
            router.post("/query", controller.query);
            router.post("/", controller.create);
            router.put("/:_id", controller.update);
            router.get("/:_id", controller.findById);
            router.delete("/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return InventoryItemDiscountRoutes;
}());
Object.seal(InventoryItemDiscountRoutes);
module.exports = InventoryItemDiscountRoutes;
//# sourceMappingURL=InventoryItemDiscountRoutes.js.map