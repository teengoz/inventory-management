"use strict";
var express = require("express");
var LemonController = require("./../../controllers/LemonController");
var router = express.Router();
var LemonRoutes = (function () {
    function LemonRoutes() {
        this._lemonController = new LemonController();
    }
    Object.defineProperty(LemonRoutes.prototype, "routes", {
        get: function () {
            var controller = this._lemonController;
            router.get("/lemons", controller.retrieve);
            router.post("/lemons", controller.create);
            //router.get("/newlemon", controller.debugCreate);
            router.put("/lemons/:_id", controller.update);
            router.get("/lemons/:_id", controller.findById);
            router.delete("/lemons/:_id", controller.delete);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return LemonRoutes;
}());
Object.seal(LemonRoutes);
module.exports = LemonRoutes;
//# sourceMappingURL=LemonRoutes.js.map