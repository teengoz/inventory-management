"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var passport = require("passport");
var UserSchema = require("../app/dataAccess/schemas/UserSchema");
var User = require("../app/model/User");
var LocalStrategy = require('passport-local').Strategy;
passport.use(new LocalStrategy({
    usernameField: 'username'
}, function (username, password, done) {
    UserSchema.findOne({ username: username }, function (err, user) {
        if (err) {
            return done(err);
        }
        if (!user) {
            return done(null, false, {
                errors: 'User not found'
            });
        }
        var _user = new User(user);
        if (!_user.validPassword(password)) {
            return done(null, false, {
                errors: 'Password is wrong'
            });
        }
        return done(null, user);
    });
}));
//# sourceMappingURL=passport.js.map